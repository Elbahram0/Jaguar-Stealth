package api

import (
	"encoding/json"
	"log"
	"net/http"
	"os"
	"strings"
	"time"

	"jaguar-core/internal/dns"
	"jaguar-core/internal/engine"
	"jaguar-core/internal/hosts"
	"jaguar-core/internal/proxy"
)

type Server struct {
	engine    *engine.Engine
	sniProxy  *proxy.SNIProxy
	hostsMgr  *hosts.Manager
	dnsClient *dns.Client
	startTime time.Time
	mode      string // "proxy" (default safe global SNI proxy) or "windivert"
}

func NewServer(
	eng *engine.Engine,
	sniProxy *proxy.SNIProxy,
	hostsMgr *hosts.Manager,
	dnsClient *dns.Client,
) *Server {
	return &Server{
		engine:    eng,
		sniProxy:  sniProxy,
		hostsMgr:  hostsMgr,
		dnsClient: dnsClient,
		startTime: time.Now(),
		mode:      "proxy",
	}
}

type StatusResponse struct {
	Running      bool         `json:"running"`
	Version      string       `json:"version"`
	Mode         string       `json:"mode"`
	UptimeSec    int64        `json:"uptime_sec"`
	Stats        proxy.Stats  `json:"stats"`
	TotalDomains int          `json:"total_domains"`
	DoHProvider  string       `json:"doh_provider"`
}

func (s *Server) HandleStatus(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	stats := s.sniProxy.GetStats()
	allDomains := s.hostsMgr.GetAllDomains()

	resp := StatusResponse{
		Running:      s.sniProxy.IsRunning(),
		Version:      "2.0.0",
		Mode:         s.mode,
		UptimeSec:    int64(time.Since(s.startTime).Seconds()),
		Stats:        stats,
		TotalDomains: len(allDomains),
		DoHProvider:  string(s.dnsClient.GetProvider()),
	}

	writeJSON(w, http.StatusOK, resp)
}

func (s *Server) HandleStart(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	// 1. Start SNI Proxy
	if err := s.sniProxy.Start(); err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Failed to start SNI proxy: " + err.Error(),
		})
		return
	}

	// 2. Apply hosts redirection
	boundHost := s.sniProxy.BoundHost()
	domains, err := s.hostsMgr.Apply(boundHost)
	if err != nil {
		_ = s.sniProxy.Stop()
		writeJSON(w, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Failed to update hosts file: " + err.Error(),
		})
		return
	}

	writeJSON(w, http.StatusOK, map[string]interface{}{
		"success":        true,
		"message":        "Jaguar Stealth Global Engine Active",
		"running":        true,
		"bound_host":     boundHost,
		"domains_count":  len(domains),
	})
}

func (s *Server) HandleStop(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	// 1. Force kill all active proxy connections and unbind ports immediately
	_ = s.sniProxy.Stop()

	// 2. Restore clean hosts file and flush DNS cache
	err := s.hostsMgr.Restore()
	if err != nil {
		log.Printf("[API] Warning restoring hosts: %v", err)
	}

	writeJSON(w, http.StatusOK, map[string]interface{}{
		"success": true,
		"message": "Jaguar Stealth stopped, hosts restored, sockets killed",
		"running": false,
	})
}

func (s *Server) HandleShutdown(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	// Clean up hosts and stop proxy immediately
	_ = s.hostsMgr.Restore()
	_ = s.sniProxy.Stop()

	writeJSON(w, http.StatusOK, map[string]interface{}{
		"success": true,
		"message": "Shutting down jaguar-core",
	})

	go func() {
		time.Sleep(150 * time.Millisecond)
		os.Exit(0)
	}()
}

type DomainsRequest struct {
	Action string `json:"action"` // "add", "remove", "set"
	Domain string `json:"domain,omitempty"`
	Domains []string `json:"domains,omitempty"`
}

func (s *Server) HandleDomains(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case http.MethodGet:
		all := s.hostsMgr.GetAllDomains()
		writeJSON(w, http.StatusOK, map[string]interface{}{
			"success": true,
			"domains": all,
			"presets": hosts.DefaultDomainPresets,
		})

	case http.MethodPost:
		var req DomainsRequest
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			http.Error(w, "Invalid JSON payload", http.StatusBadRequest)
			return
		}

		if req.Action == "add" && req.Domain != "" {
			s.hostsMgr.AddCustomDomain(req.Domain)
			if s.sniProxy.IsRunning() {
				_, _ = s.hostsMgr.Apply(s.sniProxy.BoundHost())
			}
		} else if req.Action == "set" && req.Domains != nil {
			s.hostsMgr.SetCustomDomains(req.Domains)
			if s.sniProxy.IsRunning() {
				_, _ = s.hostsMgr.Apply(s.sniProxy.BoundHost())
			}
		}

		writeJSON(w, http.StatusOK, map[string]interface{}{
			"success": true,
			"domains": s.hostsMgr.GetAllDomains(),
		})

	default:
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
	}
}

type ConfigUpdateRequest struct {
	DoHProvider   string   `json:"doh_provider,omitempty"`
	CustomDomains []string `json:"custom_domains,omitempty"`
}

func (s *Server) HandleConfig(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var req ConfigUpdateRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid JSON payload", http.StatusBadRequest)
		return
	}

	if req.DoHProvider != "" {
		s.dnsClient.SetProvider(dns.Provider(req.DoHProvider))
	}
	if req.CustomDomains != nil {
		s.hostsMgr.SetCustomDomains(req.CustomDomains)
		if s.sniProxy.IsRunning() {
			_, _ = s.hostsMgr.Apply(s.sniProxy.BoundHost())
		}
	}

	writeJSON(w, http.StatusOK, map[string]interface{}{
		"success": true,
		"doh":     s.dnsClient.GetProvider(),
		"domains": s.hostsMgr.GetAllDomains(),
	})
}

func (s *Server) HandleResolveDNS(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	domain := strings.TrimSpace(r.URL.Query().Get("domain"))
	if domain == "" {
		http.Error(w, "Query parameter 'domain' is required", http.StatusBadRequest)
		return
	}

	ips, err := s.dnsClient.Resolve(r.Context(), domain)
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   err.Error(),
		})
		return
	}

	writeJSON(w, http.StatusOK, map[string]interface{}{
		"success": true,
		"domain":  domain,
		"ips":     ips,
	})
}

func writeJSON(w http.ResponseWriter, code int, v interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}
