package hosts

import (
	"bufio"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

const (
	HostsFilePath = `C:\Windows\System32\drivers\etc\hosts`
	MarkerStart   = "# === Jaguar Stealth START ==="
	MarkerEnd     = "# === Jaguar Stealth END ==="
)

var DefaultDomainPresets = map[string][]string{
	"discord": {
		"discord.com",
		"www.discord.com",
		"discordapp.com",
		"www.discordapp.com",
		"gateway.discord.gg",
		"cdn.discordapp.com",
		"media.discordapp.net",
		"dl.discordapp.net",
		"updates.discord.com",
		"status.discord.com",
		"discord.gg",
		"discord.media",
		"discordapp.net",
		"latency.discord.media",
	},
	"roblox": {
		"roblox.com",
		"www.roblox.com",
		"api.roblox.com",
		"apis.roblox.com",
		"clientsettings.roblox.com",
		"clientsettingscdn.roblox.com",
		"setup.rbxcdn.com",
		"versioncompatibility.api.roblox.com",
		"auth.roblox.com",
		"assetgame.roblox.com",
		"ecsv2.roblox.com",
		"gamepersistence.roblox.com",
		"web.roblox.com",
	},
	"twitter": {
		"x.com",
		"www.x.com",
		"twitter.com",
		"www.twitter.com",
		"api.twitter.com",
		"api.x.com",
		"abs.twimg.com",
		"pbs.twimg.com",
		"ton.twitter.com",
		"t.co",
	},
	"media": {
		"wattpad.com",
		"www.wattpad.com",
		"imgur.com",
		"i.imgur.com",
		"pastebin.com",
		"eksisozluk.com",
		"eksisozluk1923.com",
	},
}

type Manager struct {
	mu            sync.Mutex
	customDomains []string
	activeDomains []string
	backupPath    string
}

func NewManager() *Manager {
	return &Manager{
		customDomains: make([]string, 0),
		activeDomains: make([]string, 0),
	}
}

func (m *Manager) GetAllDomains() []string {
	m.mu.Lock()
	defer m.mu.Unlock()

	seen := make(map[string]bool)
	var result []string

	for _, list := range DefaultDomainPresets {
		for _, d := range list {
			d = strings.ToLower(strings.TrimSpace(d))
			if d != "" && !seen[d] {
				seen[d] = true
				result = append(result, d)
			}
		}
	}

	for _, d := range m.customDomains {
		d = strings.ToLower(strings.TrimSpace(d))
		if d != "" && !seen[d] {
			seen[d] = true
			result = append(result, d)
		}
	}

	return result
}

func (m *Manager) AddCustomDomain(domain string) {
	domain = strings.ToLower(strings.TrimSpace(domain))
	if domain == "" {
		return
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	for _, d := range m.customDomains {
		if d == domain {
			return
		}
	}
	m.customDomains = append(m.customDomains, domain)
}

func (m *Manager) SetCustomDomains(domains []string) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.customDomains = make([]string, 0, len(domains))
	for _, d := range domains {
		d = strings.ToLower(strings.TrimSpace(d))
		if d != "" {
			m.customDomains = append(m.customDomains, d)
		}
	}
}

func (m *Manager) Backup() error {
	m.mu.Lock()
	defer m.mu.Unlock()

	content, err := os.ReadFile(HostsFilePath)
	if err != nil {
		return fmt.Errorf("failed to read hosts file: %w", err)
	}

	appData := os.Getenv("APPDATA")
	if appData == "" {
		appData = os.TempDir()
	}
	backupDir := filepath.Join(appData, "JaguarStealth", "backups")
	_ = os.MkdirAll(backupDir, 0755)

	ts := time.Now().Format("20060102_150405")
	bPath := filepath.Join(backupDir, fmt.Sprintf("hosts_backup_%s.txt", ts))
	if err := os.WriteFile(bPath, content, 0644); err != nil {
		return fmt.Errorf("failed to save hosts backup: %w", err)
	}
	m.backupPath = bPath
	return nil
}

func (m *Manager) Apply(targetIP string) ([]string, error) {
	_ = m.Backup()

	domains := m.GetAllDomains()
	if len(domains) == 0 {
		return nil, nil
	}

	m.mu.Lock()
	defer m.mu.Unlock()

	content, err := os.ReadFile(HostsFilePath)
	if err != nil {
		return nil, fmt.Errorf("failed to read hosts: %w", err)
	}

	cleaned := stripMarkerBlock(string(content))

	var b strings.Builder
	b.WriteString(cleaned)
	if !strings.HasSuffix(cleaned, "\n") {
		b.WriteString("\r\n")
	}
	b.WriteString(MarkerStart + "\r\n")
	b.WriteString(fmt.Sprintf("# Applied by Jaguar Stealth on %s\r\n", time.Now().Format("2006-01-02 15:04:05")))
	for _, d := range domains {
		b.WriteString(fmt.Sprintf("%-16s %s\r\n", targetIP, d))
	}
	b.WriteString(MarkerEnd + "\r\n")

	if err := os.WriteFile(HostsFilePath, []byte(b.String()), 0644); err != nil {
		return nil, fmt.Errorf("failed to write hosts file: %w", err)
	}

	m.activeDomains = domains
	m.FlushDNS()
	return domains, nil
}

func (m *Manager) Restore() error {
	m.mu.Lock()
	defer m.mu.Unlock()

	content, err := os.ReadFile(HostsFilePath)
	if err != nil {
		return fmt.Errorf("failed to read hosts file: %w", err)
	}

	cleaned := stripMarkerBlock(string(content))
	if err := os.WriteFile(HostsFilePath, []byte(cleaned), 0644); err != nil {
		return fmt.Errorf("failed to write hosts file: %w", err)
	}

	m.activeDomains = nil
	m.FlushDNS()
	return nil
}

func (m *Manager) FlushDNS() {
	cmd := exec.Command("ipconfig", "/flushdns")
	_ = cmd.Run()

	psCmd := exec.Command("powershell", "-NoProfile", "-Command", "Clear-DnsClientCache -ErrorAction SilentlyContinue")
	_ = psCmd.Run()
}

func stripMarkerBlock(content string) string {
	var lines []string
	scanner := bufio.NewScanner(strings.NewReader(content))
	inside := false

	for scanner.Scan() {
		line := scanner.Text()
		trimmed := strings.TrimSpace(line)
		if trimmed == MarkerStart {
			inside = true
			continue
		}
		if trimmed == MarkerEnd {
			inside = false
			continue
		}
		if !inside {
			lines = append(lines, line)
		}
	}

	res := strings.Join(lines, "\r\n")
	return strings.TrimRight(res, "\r\n") + "\r\n"
}
