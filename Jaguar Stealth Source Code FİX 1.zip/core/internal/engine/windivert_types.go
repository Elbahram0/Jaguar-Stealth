﻿package engine

import "unsafe"

const (
	WINDIVERT_LAYER_NETWORK         = 0
	WINDIVERT_LAYER_NETWORK_FORWARD = 1
	WINDIVERT_LAYER_FLOW            = 2
	WINDIVERT_LAYER_SOCKET          = 3
	WINDIVERT_LAYER_REFLECT         = 4

	WINDIVERT_FLAG_SNIFF     = 1
	WINDIVERT_FLAG_DROP      = 2
	WINDIVERT_FLAG_FRAGMENTS = 4
	WINDIVERT_FLAG_NO_CHECKSUM = 1024

	WINDIVERT_HELPER_NO_IP_CHECKSUM  = 1
	WINDIVERT_HELPER_NO_ICMP_CHECKSUM = 2
	WINDIVERT_HELPER_NO_ICMPV6_CHECKSUM = 4
	WINDIVERT_HELPER_NO_TCP_CHECKSUM = 8
	WINDIVERT_HELPER_NO_UDP_CHECKSUM = 16
)

// WINDIVERT_DATA_NETWORK represents the network layer data in WinDivert 2.x
type WINDIVERT_DATA_NETWORK struct {
	IfIdx     uint32
	SubIfIdx  uint32
}

// WinDivertAddress matches WINDIVERT_ADDRESS struct in WinDivert 2.2
type WinDivertAddress struct {
	Timestamp int64
	Layer     uint8
	Event     uint8
	Flags     uint8
	Reserved  uint8
	Data      [64]byte
}

func (addr *WinDivertAddress) SetOutbound(outbound bool) {
	if outbound {
		addr.Flags |= 0x02 // Outbound flag
	} else {
		addr.Flags &= ^uint8(0x02)
	}
}

func (addr *WinDivertAddress) IsOutbound() bool {
	return (addr.Flags & 0x02) != 0
}

func (addr *WinDivertAddress) NetworkData() *WINDIVERT_DATA_NETWORK {
	return (*WINDIVERT_DATA_NETWORK)(unsafe.Pointer(&addr.Data[0]))
}
