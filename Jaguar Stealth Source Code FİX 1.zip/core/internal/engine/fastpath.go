package engine

import (
	"bytes"
	"encoding/binary"
)

// isLikelyTLSClientHello performs an ultra-fast, zero-allocation pre-check
// on the raw IP packet buffer.
// Returns whether the packet is a TLS ClientHello and its TCP payload offset.
func isLikelyTLSClientHello(raw []byte) (bool, int) {
	if len(raw) < 40 {
		return false, 0
	}

	version := raw[0] >> 4
	var ipHdrLen int

	if version == 4 {
		ipHdrLen = int(raw[0]&0x0F) * 4
		if len(raw) < ipHdrLen+20 || raw[9] != 6 { // Must be TCP
			return false, 0
		}
	} else if version == 6 {
		ipHdrLen = 40
		if len(raw) < 60 || raw[6] != 6 { // Must be TCP
			return false, 0
		}
	} else {
		return false, 0
	}

	tcpStart := ipHdrLen
	if len(raw) < tcpStart+20 {
		return false, 0
	}

	tcpHdrLen := int(raw[tcpStart+12]>>4) * 4
	payloadStart := tcpStart + tcpHdrLen

	// Check if packet has enough bytes for TLS Record (5 bytes) + Handshake Header (4 bytes)
	if len(raw) < payloadStart+9 {
		return false, 0
	}

	// 0x16 = TLS Handshake
	// 0x03 = TLS 1.0 - 1.3
	// 0x01 = ClientHello
	if raw[payloadStart] == 0x16 && raw[payloadStart+1] == 0x03 && raw[payloadStart+5] == 0x01 {
		return true, payloadStart
	}

	return false, 0
}

// isOutboundQUIC checks if the packet is outbound UDP 443 (HTTP/3 QUIC).
func isOutboundQUIC(raw []byte) bool {
	if len(raw) < 28 {
		return false
	}
	version := raw[0] >> 4
	if version == 4 {
		ipHdrLen := int(raw[0]&0x0F) * 4
		if len(raw) < ipHdrLen+8 || raw[9] != 17 { // 17 = UDP
			return false
		}
		dstPort := binary.BigEndian.Uint16(raw[ipHdrLen+2 : ipHdrLen+4])
		return dstPort == 443
	} else if version == 6 {
		if len(raw) < 48 || raw[6] != 17 { // 17 = UDP
			return false
		}
		dstPort := binary.BigEndian.Uint16(raw[42:44])
		return dstPort == 443
	}
	return false
}

// isHTTPPort80 checks if the packet is outbound TCP port 80.
func isHTTPPort80(raw []byte) bool {
	if len(raw) < 40 {
		return false
	}
	version := raw[0] >> 4
	var ipHdrLen int
	if version == 4 {
		ipHdrLen = int(raw[0]&0x0F) * 4
		if len(raw) < ipHdrLen+20 || raw[9] != 6 {
			return false
		}
	} else if version == 6 {
		ipHdrLen = 40
		if len(raw) < 60 || raw[6] != 6 {
			return false
		}
	} else {
		return false
	}
	dstPort := binary.BigEndian.Uint16(raw[ipHdrLen+2 : ipHdrLen+4])
	return dstPort == 80
}

// obfuscateHTTPHost modifies the Host header in HTTP requests to bypass passive HTTP DPI.
func obfuscateHTTPHost(raw []byte) []byte {
	idx := bytes.Index(raw, []byte("Host: "))
	if idx != -1 {
		modified := make([]byte, len(raw))
		copy(modified, raw)
		// Change "Host" to "hoSt"
		copy(modified[idx:idx+4], []byte("hoSt"))

		version := raw[0] >> 4
		ipHdrLen := 20
		if version == 4 {
			ipHdrLen = int(raw[0]&0x0F) * 4
		} else {
			ipHdrLen = 40
		}
		tcpHdrLen := int(raw[ipHdrLen+12]>>4) * 4
		recalcChecksums(modified, version == 6, ipHdrLen, tcpHdrLen)
		return modified
	}
	return raw
}