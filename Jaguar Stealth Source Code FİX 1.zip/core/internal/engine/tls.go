package engine

import (
	"encoding/binary"
	"strings"
)

const (
	tlsContentTypeHandshake = 0x16
	tlsHandshakeClientHello = 0x01
	tlsExtServerName        = 0x0000
)

// TLSInfo contains parsed information from a TLS ClientHello packet.
type TLSInfo struct {
	IsClientHello bool
	SNI           string
	SNIOffset     int // Offset of SNI within the TCP payload
	SNILength     int
}

// ParseClientHello attempts to parse a TLS ClientHello record from a TCP payload.
func ParseClientHello(payload []byte) *TLSInfo {
	if len(payload) < 9 {
		return nil
	}

	// Check if this is a TLS Handshake record
	if payload[0] != tlsContentTypeHandshake {
		return nil
	}

	// Major version check (TLS 1.0 - 1.3: 0x03)
	if payload[1] != 0x03 {
		return nil
	}

	recordLen := int(binary.BigEndian.Uint16(payload[3:5]))
	if len(payload) < 5+recordLen {
		return nil
	}

	// Handshake Message
	if payload[5] != tlsHandshakeClientHello {
		return nil
	}

	info := &TLSInfo{
		IsClientHello: true,
	}

	offset := 5 + 4 // Handshake type + 3 bytes length
	if len(payload) < offset+34 {
		return info
	}

	// Skip ClientVersion (2 bytes) + Random (32 bytes)
	offset += 2 + 32

	// Skip Session ID
	if offset >= len(payload) {
		return info
	}
	sessionIDLen := int(payload[offset])
	offset += 1 + sessionIDLen

	// Skip Cipher Suites
	if offset+2 > len(payload) {
		return info
	}
	cipherSuitesLen := int(binary.BigEndian.Uint16(payload[offset : offset+2]))
	offset += 2 + cipherSuitesLen

	// Skip Compression Methods
	if offset+1 > len(payload) {
		return info
	}
	compressionMethodsLen := int(payload[offset])
	offset += 1 + compressionMethodsLen

	// Check Extensions
	if offset+2 > len(payload) {
		return info
	}
	extensionsLen := int(binary.BigEndian.Uint16(payload[offset : offset+2]))
	offset += 2

	extensionsEnd := offset + extensionsLen
	if extensionsEnd > len(payload) {
		extensionsEnd = len(payload)
	}

	// Loop through extensions to find SNI (0x0000)
	for offset+4 <= extensionsEnd {
		extType := binary.BigEndian.Uint16(payload[offset : offset+2])
		extLen := int(binary.BigEndian.Uint16(payload[offset+2 : offset+4]))
		offset += 4

		if offset+extLen > extensionsEnd {
			break
		}

		if extType == tlsExtServerName {
			if extLen >= 5 {
				nameType := payload[offset+2]
				if nameType == 0 { // host_name
					nameLen := int(binary.BigEndian.Uint16(payload[offset+3 : offset+5]))
					nameStart := offset + 5
					if nameStart+nameLen <= offset+extLen {
						info.SNI = strings.ToLower(string(payload[nameStart : nameStart+nameLen]))
						info.SNIOffset = nameStart
						info.SNILength = nameLen
					}
				}
			}
			break
		}

		offset += extLen
	}

	return info
}

// FindSplitPoints calculates the optimal fragmentation split points for the TCP payload.
// Uses an Adaptive Global Multi-Split Strategy:
// 1. First split at 2 bytes: Hides the 0x16 0x03 signature from stateful TSPU/Sandvine DPI.
// 2. Second split in the middle of SNI: Breaks the host string.
func FindSplitPoints(payload []byte, info *TLSInfo, splitPos int) []int {
	if len(payload) <= 4 {
		return nil
	}

	// If explicit split position was set
	if splitPos > 0 && splitPos < len(payload) {
		return []int{splitPos}
	}

	var points []int

	// 1st split: 2 bytes (Zapret split2 technique - defeats Russia TSPU & Superonline)
	if len(payload) > 4 {
		points = append(points, 2)
	}

	// 2nd split: Middle of SNI
	if info != nil && info.SNIOffset > 0 && info.SNILength > 1 {
		sniSplit := info.SNIOffset + (info.SNILength / 2)
		if sniSplit > 4 && sniSplit < len(payload) {
			points = append(points, sniSplit)
		}
	} else if len(payload) > 30 {
		points = append(points, 30)
	}

	return points
}

// CheckIfHostMatches checks if a domain matches against bypass or block lists
func CheckIfHostMatches(host string, patterns []string) bool {
	if len(patterns) == 0 {
		return true
	}
	for _, p := range patterns {
		p = strings.TrimSpace(strings.ToLower(p))
		if p == "" {
			continue
		}
		if p == "*" || p == host || strings.HasSuffix(host, "."+p) || strings.Contains(host, p) {
			return true
		}
	}
	return false
}