package engine

import (
	"encoding/binary"
	"errors"
	"net"
)

var (
	ErrNotTCP          = errors.New("packet is not TCP")
	ErrInvalidPacket   = errors.New("packet length is invalid")
	ErrNoPayload       = errors.New("packet has no TCP payload")
)

// ParsedPacket represents an unpacked IP/TCP packet.
type ParsedPacket struct {
	IsIPv6       bool
	IPHeaderLen  int
	TCPHeaderLen int
	TotalLen     int
	SrcIP        net.IP
	DstIP        net.IP
	SrcPort      uint16
	DstPort      uint16
	SeqNum       uint32
	AckNum       uint32
	Flags        uint8
	Payload      []byte
	Raw          []byte
}

// ParsePacket extracts headers and payload from a raw IP packet.
func ParsePacket(raw []byte) (*ParsedPacket, error) {
	if len(raw) < 20 {
		return nil, ErrInvalidPacket
	}

	version := raw[0] >> 4
	p := &ParsedPacket{Raw: raw}

	if version == 4 {
		p.IsIPv6 = false
		p.IPHeaderLen = int(raw[0]&0x0F) * 4
		if len(raw) < p.IPHeaderLen {
			return nil, ErrInvalidPacket
		}
		p.TotalLen = int(binary.BigEndian.Uint16(raw[2:4]))
		if p.TotalLen > len(raw) {
			p.TotalLen = len(raw)
		}
		protocol := raw[9]
		if protocol != 6 { // TCP
			return nil, ErrNotTCP
		}
		p.SrcIP = net.IP(raw[12:16])
		p.DstIP = net.IP(raw[16:20])
	} else if version == 6 {
		p.IsIPv6 = true
		p.IPHeaderLen = 40
		if len(raw) < 40 {
			return nil, ErrInvalidPacket
		}
		payloadLen := int(binary.BigEndian.Uint16(raw[4:6]))
		p.TotalLen = 40 + payloadLen
		if p.TotalLen > len(raw) {
			p.TotalLen = len(raw)
		}
		nextHdr := raw[6]
		if nextHdr != 6 { // TCP
			return nil, ErrNotTCP
		}
		p.SrcIP = net.IP(raw[8:24])
		p.DstIP = net.IP(raw[24:40])
	} else {
		return nil, ErrInvalidPacket
	}

	tcpStart := p.IPHeaderLen
	if len(raw) < tcpStart+20 {
		return nil, ErrInvalidPacket
	}

	p.SrcPort = binary.BigEndian.Uint16(raw[tcpStart : tcpStart+2])
	p.DstPort = binary.BigEndian.Uint16(raw[tcpStart+2 : tcpStart+4])
	p.SeqNum = binary.BigEndian.Uint32(raw[tcpStart+4 : tcpStart+8])
	p.AckNum = binary.BigEndian.Uint32(raw[tcpStart+8 : tcpStart+12])
	p.TCPHeaderLen = int(raw[tcpStart+12]>>4) * 4
	if len(raw) < tcpStart+p.TCPHeaderLen {
		return nil, ErrInvalidPacket
	}
	p.Flags = raw[tcpStart+13]

	payloadStart := tcpStart + p.TCPHeaderLen
	if payloadStart > p.TotalLen {
		return nil, ErrNoPayload
	}
	p.Payload = raw[payloadStart:p.TotalLen]
	if len(p.Payload) == 0 {
		return nil, ErrNoPayload
	}

	return p, nil
}

// SplitTCPPacketMulti splits a TCP packet across multiple offsets.
// Handles 1, 2, or 3 fragments with strict TCP sequence numbers and checksums.
func SplitTCPPacketMulti(p *ParsedPacket, splitOffsets []int) ([][]byte, error) {
	if len(splitOffsets) == 0 {
		return [][]byte{p.Raw}, nil
	}

	// Filter and sort valid offsets
	var validOffsets []int
	last := 0
	for _, offset := range splitOffsets {
		if offset > last && offset < len(p.Payload) {
			validOffsets = append(validOffsets, offset)
			last = offset
		}
	}

	if len(validOffsets) == 0 {
		return [][]byte{p.Raw}, nil
	}

	boundaries := append([]int{0}, validOffsets...)
	boundaries = append(boundaries, len(p.Payload))

	var fragments [][]byte
	for i := 0; i < len(boundaries)-1; i++ {
		start := boundaries[i]
		end := boundaries[i+1]
		fragPayload := p.Payload[start:end]

		frag := make([]byte, p.IPHeaderLen+p.TCPHeaderLen+len(fragPayload))
		copy(frag[:p.IPHeaderLen+p.TCPHeaderLen], p.Raw[:p.IPHeaderLen+p.TCPHeaderLen])
		copy(frag[p.IPHeaderLen+p.TCPHeaderLen:], fragPayload)

		// Update lengths
		updatePacketLengths(frag, p.IsIPv6, p.IPHeaderLen, p.TCPHeaderLen, len(fragPayload))

		// Update TCP Sequence Number
		tcpStart := p.IPHeaderLen
		newSeq := p.SeqNum + uint32(start)
		binary.BigEndian.PutUint32(frag[tcpStart+4:tcpStart+8], newSeq)

		// Flags: clear PSH on all fragments except the last one
		if i < len(boundaries)-2 {
			frag[p.IPHeaderLen+13] &= ^uint8(0x08)
		}

		// Recalculate IP & TCP Checksums
		recalcChecksums(frag, p.IsIPv6, p.IPHeaderLen, p.TCPHeaderLen)

		fragments = append(fragments, frag)
	}

	return fragments, nil
}

// SplitTCPPacket splits at a single offset.
func SplitTCPPacket(p *ParsedPacket, splitOffset int) ([][]byte, error) {
	return SplitTCPPacketMulti(p, []int{splitOffset})
}

func updatePacketLengths(raw []byte, isIPv6 bool, ipHdrLen, tcpHdrLen, payloadLen int) {
	totalLen := ipHdrLen + tcpHdrLen + payloadLen
	if !isIPv6 {
		binary.BigEndian.PutUint16(raw[2:4], uint16(totalLen))
	} else {
		payloadOnly := tcpHdrLen + payloadLen
		binary.BigEndian.PutUint16(raw[4:6], uint16(payloadOnly))
	}
}

func recalcChecksums(raw []byte, isIPv6 bool, ipHdrLen, tcpHdrLen int) {
	if !isIPv6 {
		// IPv4 Header Checksum
		raw[10] = 0
		raw[11] = 0
		ipCsum := computeChecksum(raw[:ipHdrLen])
		binary.BigEndian.PutUint16(raw[10:12], ipCsum)

		// TCP Checksum with IPv4 Pseudo-Header
		tcpStart := ipHdrLen
		raw[tcpStart+16] = 0
		raw[tcpStart+17] = 0

		srcIP := raw[12:16]
		dstIP := raw[16:20]
		tcpLen := len(raw) - ipHdrLen

		pseudo := make([]byte, 12+tcpLen)
		copy(pseudo[0:4], srcIP)
		copy(pseudo[4:8], dstIP)
		pseudo[8] = 0
		pseudo[9] = 6 // Protocol TCP
		binary.BigEndian.PutUint16(pseudo[10:12], uint16(tcpLen))
		copy(pseudo[12:], raw[tcpStart:])

		tcpCsum := computeChecksum(pseudo)
		binary.BigEndian.PutUint16(raw[tcpStart+16:tcpStart+18], tcpCsum)
	} else {
		// TCP Checksum with IPv6 Pseudo-Header
		tcpStart := ipHdrLen
		raw[tcpStart+16] = 0
		raw[tcpStart+17] = 0

		srcIP := raw[8:24]
		dstIP := raw[24:40]
		tcpLen := len(raw) - ipHdrLen

		pseudo := make([]byte, 40+tcpLen)
		copy(pseudo[0:16], srcIP)
		copy(pseudo[16:32], dstIP)
		binary.BigEndian.PutUint32(pseudo[32:36], uint32(tcpLen))
		pseudo[36] = 0
		pseudo[37] = 0
		pseudo[38] = 0
		pseudo[39] = 6 // Next Header TCP
		copy(pseudo[40:], raw[tcpStart:])

		tcpCsum := computeChecksum(pseudo)
		binary.BigEndian.PutUint16(raw[tcpStart+16:tcpStart+18], tcpCsum)
	}
}

func computeChecksum(data []byte) uint16 {
	var sum uint32
	n := len(data)
	for i := 0; i < n-1; i += 2 {
		sum += uint32(binary.BigEndian.Uint16(data[i : i+2]))
	}
	if n%2 == 1 {
		sum += uint32(data[n-1]) << 8
	}
	for (sum >> 16) > 0 {
		sum = (sum & 0xFFFF) + (sum >> 16)
	}
	return ^uint16(sum)
}