package engine

import (
	"context"
	"log"
	"runtime"
	"sync"
	"sync/atomic"
	"time"
)

// EngineConfig holds configuration options for the DPI bypass engine.
type EngineConfig struct {
	Filter            string   `json:"filter"`
	SplitPosition     int      `json:"split_position"` // 0 = auto adaptive multi-split
	IncludeDomains    []string `json:"include_domains"` // Empty = all
	ExcludeDomains    []string `json:"exclude_domains"`
	AutoFragmentHTTPS bool     `json:"auto_fragment_https"`
}

func DefaultConfig() EngineConfig {
	return EngineConfig{
		Filter:            "outbound and ((tcp.DstPort == 443 and tcp.PayloadLength > 0) or (tcp.DstPort == 80 and tcp.PayloadLength > 0) or (udp.DstPort == 443))",
		SplitPosition:     0, // Auto adaptive multi-split
		AutoFragmentHTTPS: true,
	}
}

// EngineStats records real-time metrics of the engine.
type EngineStats struct {
	IsRunning          bool      `json:"is_running"`
	KernelDriverActive bool      `json:"kernel_driver_active"`
	PacketsProcessed   uint64    `json:"packets_processed"`
	PacketsFragmented  uint64    `json:"packets_fragmented"`
	PacketsBypassed    uint64    `json:"packets_bypassed"`
	ErrorCount         uint64    `json:"error_count"`
	StartTime          time.Time `json:"start_time,omitempty"`
	LastSNI            string    `json:"last_sni,omitempty"`
	StatusMessage      string    `json:"status_message,omitempty"`
}

// Engine manages the WinDivert lifecycle and packet processing loop.
type Engine struct {
	mu                 sync.RWMutex
	handle             Handle
	config             EngineConfig
	running            bool
	kernelDriverActive bool
	statusMessage      string
	cancel             context.CancelFunc
	wg                 sync.WaitGroup
	startTime          time.Time

	packetsProcessed  uint64
	packetsFragmented uint64
	packetsBypassed   uint64
	errorCount        uint64

	lastSNIMu sync.RWMutex
	lastSNI   string
}

func NewEngine(cfg EngineConfig) *Engine {
	return &Engine{
		config: cfg,
	}
}

func (e *Engine) IsRunning() bool {
	e.mu.RLock()
	defer e.mu.RUnlock()
	return e.running
}

func (e *Engine) GetConfig() EngineConfig {
	e.mu.RLock()
	defer e.mu.RUnlock()
	return e.config
}

func (e *Engine) SetConfig(cfg EngineConfig) {
	e.mu.Lock()
	defer e.mu.Unlock()
	e.config = cfg
}

func (e *Engine) GetStats() EngineStats {
	e.mu.RLock()
	running := e.running
	kActive := e.kernelDriverActive
	msg := e.statusMessage
	st := e.startTime
	e.mu.RUnlock()

	e.lastSNIMu.RLock()
	sni := e.lastSNI
	e.lastSNIMu.RUnlock()

	return EngineStats{
		IsRunning:          running,
		KernelDriverActive: kActive,
		PacketsProcessed:   atomic.LoadUint64(&e.packetsProcessed),
		PacketsFragmented:  atomic.LoadUint64(&e.packetsFragmented),
		PacketsBypassed:    atomic.LoadUint64(&e.packetsBypassed),
		ErrorCount:         atomic.LoadUint64(&e.errorCount),
		StartTime:          st,
		LastSNI:            sni,
		StatusMessage:      msg,
	}
}

func (e *Engine) Start() error {
	e.mu.Lock()
	defer e.mu.Unlock()

	if e.running {
		return nil
	}

	filter := e.config.Filter
	if filter == "" {
		filter = "outbound and ((tcp.DstPort == 443 and tcp.PayloadLength > 0) or (tcp.DstPort == 80 and tcp.PayloadLength > 0) or (udp.DstPort == 443))"
	}

	ctx, cancel := context.WithCancel(context.Background())
	e.cancel = cancel
	e.running = true
	e.startTime = time.Now()

	handle, err := DivertOpen(filter, WINDIVERT_LAYER_NETWORK, 0, 0)
	if err != nil {
		log.Printf("[Engine] WinDivert driver could not be opened: %v", err)
		log.Println("[Engine] Continuing in User-Mode DoH Protected Mode. (Run as Administrator for Kernel TCP Fragmentation)")
		e.handle = InvalidHandle
		e.kernelDriverActive = false
		e.statusMessage = "DoH Korumasi Aktif (Kernel icin Yonetici Olarak Baslatin)"
		return nil
	}

	e.handle = handle
	e.kernelDriverActive = true
	e.statusMessage = "Global Adaptive Stealth Aktif"

	numWorkers := runtime.NumCPU()
	if numWorkers < 2 {
		numWorkers = 2
	}
	if numWorkers > 8 {
		numWorkers = 8
	}

	log.Printf("[Engine] WinDivert Global Engine started with %d workers (filter: %s)", numWorkers, filter)

	for i := 0; i < numWorkers; i++ {
		e.wg.Add(1)
		go e.workerLoop(ctx, handle, i)
	}

	return nil
}

func (e *Engine) Stop() error {
	e.mu.Lock()
	if !e.running {
		e.mu.Unlock()
		return nil
	}

	e.running = false
	e.kernelDriverActive = false
	e.statusMessage = "Durduruldu"

	if e.cancel != nil {
		e.cancel()
	}
	handle := e.handle
	e.handle = InvalidHandle
	e.mu.Unlock()

	if handle != InvalidHandle {
		DivertClose(handle)
	}

	e.wg.Wait()
	log.Println("[Engine] Stopped WinDivert engine")
	return nil
}

func (e *Engine) workerLoop(ctx context.Context, handle Handle, workerID int) {
	defer e.wg.Done()

	buffer := make([]byte, 65535)
	var addr WinDivertAddress

	for {
		select {
		case <-ctx.Done():
			return
		default:
		}

		n, err := DivertRecv(handle, buffer, &addr)
		if err != nil {
			if !e.IsRunning() {
				return
			}
			atomic.AddUint64(&e.errorCount, 1)
			continue
		}

		atomic.AddUint64(&e.packetsProcessed, 1)
		packetRaw := buffer[:n]

		// 1. QUIC (HTTP/3 UDP 443) DROP:
		// Forces browsers to immediately connect over TCP 443 without 5-second timeout stalls
		if isOutboundQUIC(packetRaw) {
			atomic.AddUint64(&e.packetsBypassed, 1)
			continue // Drop QUIC packet!
		}

		// 2. HTTP Port 80 Obfuscation:
		if isHTTPPort80(packetRaw) {
			modified := obfuscateHTTPHost(packetRaw)
			DivertSend(handle, modified, &addr)
			atomic.AddUint64(&e.packetsFragmented, 1)
			continue
		}

		// 3. ULTRA-FAST PATH FOR HTTPS DATA:
		// If not TLS ClientHello, re-inject immediately with zero memory allocation!
		isClientHello, _ := isLikelyTLSClientHello(packetRaw)
		if !isClientHello {
			DivertSend(handle, packetRaw, &addr)
			atomic.AddUint64(&e.packetsBypassed, 1)
			continue
		}

		// 4. GLOBAL ADAPTIVE CLIENTHELLO FRAGMENTATION:
		e.processClientHello(handle, packetRaw, &addr)
	}
}

func (e *Engine) processClientHello(handle Handle, raw []byte, addr *WinDivertAddress) {
	parsed, err := ParsePacket(raw)
	if err != nil || len(parsed.Payload) == 0 {
		DivertSend(handle, raw, addr)
		atomic.AddUint64(&e.packetsBypassed, 1)
		return
	}

	tlsInfo := ParseClientHello(parsed.Payload)
	if tlsInfo == nil || !tlsInfo.IsClientHello {
		DivertSend(handle, raw, addr)
		atomic.AddUint64(&e.packetsBypassed, 1)
		return
	}

	if tlsInfo.SNI != "" {
		e.lastSNIMu.Lock()
		e.lastSNI = tlsInfo.SNI
		e.lastSNIMu.Unlock()
	}

	e.mu.RLock()
	cfg := e.config
	e.mu.RUnlock()

	if len(cfg.ExcludeDomains) > 0 && CheckIfHostMatches(tlsInfo.SNI, cfg.ExcludeDomains) {
		DivertSend(handle, raw, addr)
		atomic.AddUint64(&e.packetsBypassed, 1)
		return
	}

	// Calculate Global Adaptive Split Points (2-byte micro split + SNI split)
	splitPoints := FindSplitPoints(parsed.Payload, tlsInfo, cfg.SplitPosition)
	if len(splitPoints) == 0 {
		DivertSend(handle, raw, addr)
		atomic.AddUint64(&e.packetsBypassed, 1)
		return
	}

	// Multi-fragment packet
	fragments, err := SplitTCPPacketMulti(parsed, splitPoints)
	if err != nil || len(fragments) < 2 {
		DivertSend(handle, raw, addr)
		atomic.AddUint64(&e.packetsBypassed, 1)
		return
	}

	for _, frag := range fragments {
		_, err := DivertSend(handle, frag, addr)
		if err != nil {
			atomic.AddUint64(&e.errorCount, 1)
		}
	}

	atomic.AddUint64(&e.packetsFragmented, 1)
}