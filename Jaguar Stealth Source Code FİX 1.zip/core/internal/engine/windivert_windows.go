//go:build windows

package engine

import (
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sync"
	"syscall"
	"unsafe"
)

const (
	WINDIVERT_PARAM_QUEUE_LEN  = 0
	WINDIVERT_PARAM_QUEUE_TIME = 1
	WINDIVERT_PARAM_QUEUE_SIZE = 2
)

var (
	winDivertDLL               *syscall.LazyDLL
	procWinDivertOpen          *syscall.LazyProc
	procWinDivertRecv          *syscall.LazyProc
	procWinDivertSend          *syscall.LazyProc
	procWinDivertClose         *syscall.LazyProc
	procWinDivertCalcChecksums *syscall.LazyProc
	procWinDivertSetParam      *syscall.LazyProc

	initOnce sync.Once
	initErr  error
)

func initWinDivert() error {
	initOnce.Do(func() {
		dllName := "WinDivert.dll"
		if execPath, err := os.Executable(); err == nil {
			cand := filepath.Join(filepath.Dir(execPath), "WinDivert.dll")
			if _, err := os.Stat(cand); err == nil {
				dllName = cand
			}
		}

		winDivertDLL = syscall.NewLazyDLL(dllName)
		if err := winDivertDLL.Load(); err != nil {
			initErr = fmt.Errorf("failed to load WinDivert.dll: %w", err)
			return
		}
		procWinDivertOpen = winDivertDLL.NewProc("WinDivertOpen")
		procWinDivertRecv = winDivertDLL.NewProc("WinDivertRecv")
		procWinDivertSend = winDivertDLL.NewProc("WinDivertSend")
		procWinDivertClose = winDivertDLL.NewProc("WinDivertClose")
		procWinDivertCalcChecksums = winDivertDLL.NewProc("WinDivertHelperCalcChecksums")
		procWinDivertSetParam = winDivertDLL.NewProc("WinDivertSetParam")
	})
	return initErr
}

type Handle uintptr

const InvalidHandle = Handle(^uintptr(0))

func DivertOpen(filter string, layer int, priority int16, flags uint64) (Handle, error) {
	if err := initWinDivert(); err != nil {
		return InvalidHandle, err
	}

	filterBytes := append([]byte(filter), 0)
	r1, _, err := procWinDivertOpen.Call(
		uintptr(unsafe.Pointer(&filterBytes[0])),
		uintptr(layer),
		uintptr(priority),
		uintptr(flags),
	)

	handle := Handle(r1)
	if handle == InvalidHandle {
		if err != nil && !errors.Is(err, syscall.Errno(0)) {
			return InvalidHandle, fmt.Errorf("WinDivertOpen failed: %w", err)
		}
		return InvalidHandle, errors.New("WinDivertOpen returned INVALID_HANDLE_VALUE")
	}

	// Optimize driver queue parameters for ultra-low latency & high throughput
	if procWinDivertSetParam != nil {
		// Queue length 8192 packets
		procWinDivertSetParam.Call(uintptr(handle), uintptr(WINDIVERT_PARAM_QUEUE_LEN), uintptr(8192))
		// Queue size 32 MB
		procWinDivertSetParam.Call(uintptr(handle), uintptr(WINDIVERT_PARAM_QUEUE_SIZE), uintptr(32*1024*1024))
		// Max queue time 1000 ms
		procWinDivertSetParam.Call(uintptr(handle), uintptr(WINDIVERT_PARAM_QUEUE_TIME), uintptr(1000))
	}

	return handle, nil
}

func DivertRecv(handle Handle, packet []byte, addr *WinDivertAddress) (uint, error) {
	var recvLen uint32
	r1, _, err := procWinDivertRecv.Call(
		uintptr(handle),
		uintptr(unsafe.Pointer(&packet[0])),
		uintptr(len(packet)),
		uintptr(unsafe.Pointer(&recvLen)),
		uintptr(unsafe.Pointer(addr)),
	)
	if r1 == 0 {
		return 0, fmt.Errorf("WinDivertRecv failed: %w", err)
	}
	return uint(recvLen), nil
}

func DivertSend(handle Handle, packet []byte, addr *WinDivertAddress) (uint, error) {
	var sendLen uint32
	r1, _, err := procWinDivertSend.Call(
		uintptr(handle),
		uintptr(unsafe.Pointer(&packet[0])),
		uintptr(len(packet)),
		uintptr(unsafe.Pointer(&sendLen)),
		uintptr(unsafe.Pointer(addr)),
	)
	if r1 == 0 {
		return 0, fmt.Errorf("WinDivertSend failed: %w", err)
	}
	return uint(sendLen), nil
}

func DivertClose(handle Handle) error {
	r1, _, err := procWinDivertClose.Call(uintptr(handle))
	if r1 == 0 {
		return fmt.Errorf("WinDivertClose failed: %w", err)
	}
	return nil
}

func DivertCalcChecksums(packet []byte, addr *WinDivertAddress, flags uint64) {
	if procWinDivertCalcChecksums == nil {
		return
	}
	procWinDivertCalcChecksums.Call(
		uintptr(unsafe.Pointer(&packet[0])),
		uintptr(len(packet)),
		uintptr(unsafe.Pointer(addr)),
		uintptr(flags),
	)
}