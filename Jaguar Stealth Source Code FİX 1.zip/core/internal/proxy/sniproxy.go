package proxy

import (
	"context"
	"fmt"
	"io"
	"log"
	"net"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"jaguar-core/internal/dns"
	"jaguar-core/internal/engine"
)

const (
	DefaultProxyPort = 443
	HttpProxyPort    = 80
	FragChunkSize    = 2
	ReadTimeout      = 12 * time.Second
)

var hardcodedFallbacks = map[string]string{
	"discord.com":         "162.159.136.232",
	"gateway.discord.gg":  "162.159.136.232",
	"updates.discord.com": "162.159.137.232",
	"cdn.discordapp.com":  "162.159.135.232",
	"roblox.com":          "128.116.119.3",
	"www.roblox.com":      "128.116.119.3",
	"x.com":               "104.244.42.1",
	"twitter.com":         "104.244.42.1",
}

type Stats struct {
	IsRunning          bool      `json:"is_running"`
	BoundHost          string    `json:"bound_host"`
	BoundPort          int       `json:"bound_port"`
	ActiveConnections  int64     `json:"active_connections"`
	TotalConnections   uint64    `json:"total_connections"`
	PacketsFragmented  uint64    `json:"packets_fragmented"`
	BytesTransferred   uint64    `json:"bytes_transferred"`
	LastSNI            string    `json:"last_sni,omitempty"`
	StartTime          time.Time `json:"start_time,omitempty"`
}

type SNIProxy struct {
	mu           sync.RWMutex
	listener     net.Listener
	httpListener net.Listener
	dnsClient    *dns.Client
	running      bool
	boundHost    string
	boundPort    int
	startTime    time.Time

	connsMu      sync.Mutex
	activeConns  map[net.Conn]struct{}

	activeConnections int64
	totalConnections  uint64
	packetsFragmented uint64
	bytesTransferred  uint64

	lastSNIMu sync.RWMutex
	lastSNI   string
}

func NewSNIProxy(dnsClient *dns.Client) *SNIProxy {
	return &SNIProxy{
		dnsClient:   dnsClient,
		activeConns: make(map[net.Conn]struct{}),
	}
}

func (p *SNIProxy) IsRunning() bool {
	p.mu.RLock()
	defer p.mu.RUnlock()
	return p.running
}

func (p *SNIProxy) BoundHost() string {
	p.mu.RLock()
	defer p.mu.RUnlock()
	return p.boundHost
}

func (p *SNIProxy) trackConn(c net.Conn) {
	p.connsMu.Lock()
	if p.activeConns == nil {
		p.activeConns = make(map[net.Conn]struct{})
	}
	p.activeConns[c] = struct{}{}
	p.connsMu.Unlock()
}

func (p *SNIProxy) untrackConn(c net.Conn) {
	p.connsMu.Lock()
	if p.activeConns != nil {
		delete(p.activeConns, c)
	}
	p.connsMu.Unlock()
}

func (p *SNIProxy) GetStats() Stats {
	p.mu.RLock()
	running := p.running
	bHost := p.boundHost
	bPort := p.boundPort
	st := p.startTime
	p.mu.RUnlock()

	p.lastSNIMu.RLock()
	sni := p.lastSNI
	p.lastSNIMu.RUnlock()

	return Stats{
		IsRunning:         running,
		BoundHost:         bHost,
		BoundPort:         bPort,
		ActiveConnections: atomic.LoadInt64(&p.activeConnections),
		TotalConnections:  atomic.LoadUint64(&p.totalConnections),
		PacketsFragmented: atomic.LoadUint64(&p.packetsFragmented),
		BytesTransferred:  atomic.LoadUint64(&p.bytesTransferred),
		LastSNI:           sni,
		StartTime:         st,
	}
}

func (p *SNIProxy) Start() error {
	p.mu.Lock()
	if p.running {
		p.mu.Unlock()
		return nil
	}

	var ln net.Listener
	var boundHost string
	var err error

	for i := 1; i <= 10; i++ {
		candidate := fmt.Sprintf("127.0.0.%d", i)
		addr := fmt.Sprintf("%s:%d", candidate, DefaultProxyPort)
		ln, err = net.Listen("tcp", addr)
		if err == nil {
			boundHost = candidate
			break
		}
	}

	if ln == nil {
		p.mu.Unlock()
		return fmt.Errorf("could not bind port %d on any 127.0.0.x: %w", DefaultProxyPort, err)
	}

	httpLn, errHttp := net.Listen("tcp", fmt.Sprintf("%s:%d", boundHost, HttpProxyPort))
	if errHttp == nil {
		p.httpListener = httpLn
		log.Printf("[SNI Proxy] HTTP port 80 redirector active on %s:80", boundHost)
		go p.httpRedirectLoop(httpLn)
	}

	p.listener = ln
	p.boundHost = boundHost
	p.boundPort = DefaultProxyPort
	p.running = true
	p.startTime = time.Now()
	p.mu.Unlock()

	log.Printf("[SNI Proxy] Transparent TLS Stealth Proxy listening on %s:%d", boundHost, DefaultProxyPort)

	go p.acceptLoop(ln)
	return nil
}

func (p *SNIProxy) Stop() error {
	p.mu.Lock()
	if !p.running {
		p.mu.Unlock()
		return nil
	}
	p.running = false
	ln := p.listener
	httpLn := p.httpListener
	p.listener = nil
	p.httpListener = nil
	p.mu.Unlock()

	if ln != nil {
		_ = ln.Close()
	}
	if httpLn != nil {
		_ = httpLn.Close()
	}

	p.connsMu.Lock()
	for c := range p.activeConns {
		_ = c.Close()
	}
	p.activeConns = make(map[net.Conn]struct{})
	p.connsMu.Unlock()

	log.Println("[SNI Proxy] Stopped transparent proxy and forcefully closed all active sockets")
	return nil
}

func (p *SNIProxy) httpRedirectLoop(ln net.Listener) {
	for {
		conn, err := ln.Accept()
		if err != nil {
			if !p.IsRunning() {
				return
			}
			continue
		}

		p.trackConn(conn)
		go func(c net.Conn) {
			defer func() {
				_ = c.Close()
				p.untrackConn(c)
			}()
			_ = c.SetReadDeadline(time.Now().Add(3 * time.Second))
			buf := make([]byte, 2048)
			n, err := c.Read(buf)
			if err != nil || n == 0 {
				return
			}

			host := "discord.com"
			path := "/"
			lines := strings.Split(string(buf[:n]), "\r\n")
			for _, line := range lines {
				lower := strings.ToLower(line)
				if strings.HasPrefix(lower, "host:") {
					host = strings.TrimSpace(line[5:])
				}
				if strings.HasPrefix(line, "GET ") || strings.HasPrefix(line, "POST ") || strings.HasPrefix(line, "HEAD ") {
					parts := strings.Split(line, " ")
					if len(parts) >= 2 {
						path = parts[1]
					}
				}
			}

			resp := fmt.Sprintf("HTTP/1.1 301 Moved Permanently\r\nLocation: https://%s%s\r\nConnection: close\r\nContent-Length: 0\r\n\r\n", host, path)
			_, _ = c.Write([]byte(resp))
		}(conn)
	}
}

func (p *SNIProxy) acceptLoop(ln net.Listener) {
	for {
		clientConn, err := ln.Accept()
		if err != nil {
			if !p.IsRunning() {
				return
			}
			continue
		}

		atomic.AddInt64(&p.activeConnections, 1)
		atomic.AddUint64(&p.totalConnections, 1)

		p.trackConn(clientConn)

		go func(c net.Conn) {
			defer func() {
				_ = c.Close()
				p.untrackConn(c)
				atomic.AddInt64(&p.activeConnections, -1)
			}()
			p.handleConnection(c)
		}(clientConn)
	}
}

func (p *SNIProxy) handleConnection(client net.Conn) {
	if tc, ok := client.(*net.TCPConn); ok {
		_ = tc.SetNoDelay(true)
	}

	_ = client.SetReadDeadline(time.Now().Add(ReadTimeout))
	buffer := make([]byte, 16384)
	n, err := client.Read(buffer)
	if err != nil || n == 0 {
		return
	}
	initialBytes := buffer[:n]

	tlsInfo := engine.ParseClientHello(initialBytes)
	sni := ""
	if tlsInfo != nil && tlsInfo.IsClientHello && tlsInfo.SNI != "" {
		sni = tlsInfo.SNI
		p.lastSNIMu.Lock()
		p.lastSNI = sni
		p.lastSNIMu.Unlock()
	}

	if sni == "" {
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	var destIP string
	ips, err := p.dnsClient.Resolve(ctx, sni)
	if err == nil && len(ips) > 0 {
		destIP = ips[0]
	} else if fb, ok := hardcodedFallbacks[sni]; ok {
		destIP = fb
	} else {
		resolved, err := net.LookupHost(sni)
		if err == nil && len(resolved) > 0 {
			destIP = resolved[0]
		}
	}

	if destIP == "" {
		return
	}

	d := net.Dialer{
		Timeout: 8 * time.Second,
	}
	remote, err := d.Dial("tcp", net.JoinHostPort(destIP, "443"))
	if err != nil {
		return
	}
	defer remote.Close()

	p.trackConn(remote)
	defer p.untrackConn(remote)

	if tc, ok := remote.(*net.TCPConn); ok {
		_ = tc.SetNoDelay(true)
	}

	for i := 0; i < len(initialBytes); i += FragChunkSize {
		end := i + FragChunkSize
		if end > len(initialBytes) {
			end = len(initialBytes)
		}
		_, err = remote.Write(initialBytes[i:end])
		if err != nil {
			return
		}
	}
	atomic.AddUint64(&p.packetsFragmented, 1)

	_ = client.SetDeadline(time.Time{})
	_ = remote.SetDeadline(time.Time{})

	var wg sync.WaitGroup
	wg.Add(2)

	go func() {
		defer wg.Done()
		copied, _ := io.Copy(remote, client)
		atomic.AddUint64(&p.bytesTransferred, uint64(copied))
		_ = remote.Close()
	}()

	go func() {
		defer wg.Done()
		copied, _ := io.Copy(client, remote)
		atomic.AddUint64(&p.bytesTransferred, uint64(copied))
		_ = client.Close()
	}()

	wg.Wait()
}
