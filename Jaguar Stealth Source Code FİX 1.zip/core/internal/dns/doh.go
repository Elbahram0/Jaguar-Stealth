package dns

import (
	"context"
	"crypto/tls"
	"encoding/json"
	"fmt"
	"net"
	"net/http"
	"net/url"
	"sync"
	"time"
)

type Provider string

const (
	ProviderFastest    Provider = "fastest" // Races Cloudflare & Google in parallel
	ProviderCloudflare Provider = "cloudflare"
	ProviderGoogle     Provider = "google"
	ProviderQuad9      Provider = "quad9"
)

type DoHResponse struct {
	Status int  `json:"Status"`
	Answer []struct {
		Name string `json:"name"`
		Type int    `json:"type"`
		TTL  int    `json:"TTL"`
		Data string `json:"data"`
	} `json:"Answer"`
}

type cachedEntry struct {
	ips       []string
	expiresAt time.Time
}

type Client struct {
	provider   Provider
	httpClient *http.Client
	cacheMu    sync.RWMutex
	cache      map[string]cachedEntry
}

func NewClient(provider Provider) *Client {
	if provider == "" {
		provider = ProviderFastest
	}

	// High-performance HTTP/2 transport with connection pooling
	transport := &http.Transport{
		Proxy: http.ProxyFromEnvironment,
		DialContext: (&net.Dialer{
			Timeout:   2 * time.Second,
			KeepAlive: 90 * time.Second,
		}).DialContext,
		ForceAttemptHTTP2:     true,
		MaxIdleConns:          100,
		MaxIdleConnsPerHost:   50,
		IdleConnTimeout:       90 * time.Second,
		TLSHandshakeTimeout:   2 * time.Second,
		ExpectContinueTimeout: 1 * time.Second,
		TLSClientConfig: &tls.Config{
			ClientSessionCache: tls.NewLRUClientSessionCache(64),
		},
	}

	return &Client{
		provider: provider,
		httpClient: &http.Client{
			Transport: transport,
			Timeout:   3 * time.Second,
		},
		cache: make(map[string]cachedEntry),
	}
}

func (c *Client) SetProvider(p Provider) {
	c.provider = p
}

func (c *Client) GetProvider() Provider {
	return c.provider
}

func (c *Client) Resolve(ctx context.Context, domain string) ([]string, error) {
	// Instant cache hit
	c.cacheMu.RLock()
	entry, exists := c.cache[domain]
	c.cacheMu.RUnlock()

	if exists && time.Now().Before(entry.expiresAt) {
		return entry.ips, nil
	}

	// Fastest-Wins Parallel Racing mode (Cloudflare vs Google)
	endpoints := []string{
		"https://1.1.1.1/dns-query",
		"https://dns.google/resolve",
	}

	if c.provider == ProviderCloudflare {
		endpoints = []string{"https://1.1.1.1/dns-query"}
	} else if c.provider == ProviderGoogle {
		endpoints = []string{"https://dns.google/resolve"}
	} else if c.provider == ProviderQuad9 {
		endpoints = []string{"https://dns.quad9.net:5053/dns-query"}
	}

	type raceResult struct {
		ips []string
		ttl int
		err error
	}

	resChan := make(chan raceResult, len(endpoints))
	raceCtx, cancel := context.WithTimeout(ctx, 2500*time.Millisecond)
	defer cancel()

	for _, ep := range endpoints {
		go func(endpoint string) {
			ips, ttl, err := c.queryEndpoint(raceCtx, endpoint, domain)
			resChan <- raceResult{ips: ips, ttl: ttl, err: err}
		}(ep)
	}

	var firstErr error
	for i := 0; i < len(endpoints); i++ {
		select {
		case res := <-resChan:
			if res.err == nil && len(res.ips) > 0 {
				// Cache result
				c.cacheMu.Lock()
				c.cache[domain] = cachedEntry{
					ips:       res.ips,
					expiresAt: time.Now().Add(time.Duration(res.ttl) * time.Second),
				}
				c.cacheMu.Unlock()
				return res.ips, nil
			}
			if firstErr == nil {
				firstErr = res.err
			}
		case <-raceCtx.Done():
			return nil, fmt.Errorf("DoH query timed out for domain: %s", domain)
		}
	}

	if firstErr != nil {
		return nil, firstErr
	}
	return nil, fmt.Errorf("no A records found for domain: %s", domain)
}

func (c *Client) queryEndpoint(ctx context.Context, endpoint string, domain string) ([]string, int, error) {
	u, err := url.Parse(endpoint)
	if err != nil {
		return nil, 0, err
	}

	q := u.Query()
	q.Set("name", domain)
	q.Set("type", "A")
	u.RawQuery = q.Encode()

	req, err := http.NewRequestWithContext(ctx, "GET", u.String(), nil)
	if err != nil {
		return nil, 0, err
	}
	req.Header.Set("Accept", "application/dns-json")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return nil, 0, err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, 0, fmt.Errorf("status %d", resp.StatusCode)
	}

	var dohResp DoHResponse
	if err := json.NewDecoder(resp.Body).Decode(&dohResp); err != nil {
		return nil, 0, err
	}

	var ips []string
	ttl := 300
	for _, ans := range dohResp.Answer {
		if ans.Type == 1 { // A record
			ips = append(ips, ans.Data)
			if ans.TTL > 0 && ans.TTL < ttl {
				ttl = ans.TTL
			}
		}
	}

	return ips, ttl, nil
}