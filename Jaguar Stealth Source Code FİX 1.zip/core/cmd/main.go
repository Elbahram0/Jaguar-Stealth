package main

import (
	"flag"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"
	"unsafe"

	"jaguar-core/internal/api"
	"jaguar-core/internal/dns"
	"jaguar-core/internal/engine"
	"jaguar-core/internal/hosts"
	"jaguar-core/internal/proxy"
)

func main() {
	port := flag.Int("port", 18231, "Port for local REST API")
	autoStart := flag.Bool("autostart", false, "Automatically start engine on launch")
	dohProvider := flag.String("doh", "fastest", "DoH provider (fastest, cloudflare, google, quad9)")
	parentPid := flag.Int("parent-pid", 0, "Parent process PID to monitor")
	flag.Parse()

	log.Printf("[Jaguar Core] Initializing Global Stealth Engine on 127.0.0.1:%d ...", *port)

	// 1. Initialize DoH Client
	dnsClient := dns.NewClient(dns.Provider(*dohProvider))

	// 2. Initialize SNI Proxy & Hosts Manager
	sniProxy := proxy.NewSNIProxy(dnsClient)
	hostsMgr := hosts.NewManager()

	// 3. Fallback engine
	eng := engine.NewEngine(engine.DefaultConfig())

	// Safety: clean up any leftover hosts entry from previous ungraceful exits
	_ = hostsMgr.Restore()

	cleanup := func() {
		log.Println("[Jaguar Core] Restoring hosts file & terminating proxies...")
		_ = hostsMgr.Restore()
		_ = sniProxy.Stop()
		_ = eng.Stop()
	}

	// Parent process watcher: automatically cleans up & terminates if Electron parent process exits
	if *parentPid > 0 {
		go func() {
			kernel32 := syscall.NewLazyDLL("kernel32.dll")
			openProcess := kernel32.NewProc("OpenProcess")
			getExitCodeProcess := kernel32.NewProc("GetExitCodeProcess")
			closeHandle := kernel32.NewProc("CloseHandle")

			for {
				time.Sleep(1500 * time.Millisecond)
				// PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
				handle, _, _ := openProcess.Call(0x1000, 0, uintptr(*parentPid))
				if handle == 0 {
					log.Printf("[Jaguar Core] Parent PID %d gone. Cleaning up and exiting...", *parentPid)
					cleanup()
					os.Exit(0)
				}
				var exitCode uint32
				res, _, _ := getExitCodeProcess.Call(handle, uintptr(unsafe.Pointer(&exitCode)))
				closeHandle.Call(handle)

				if res == 0 || exitCode != 259 {
					log.Printf("[Jaguar Core] Parent PID %d exited (%d). Cleaning up...", *parentPid, exitCode)
					cleanup()
					os.Exit(0)
				}
			}
		}()
	}

	// If autostart requested
	if *autoStart {
		log.Println("[Jaguar Core] Auto-starting Global SNI Proxy and Hosts redirection...")
		if err := sniProxy.Start(); err != nil {
			log.Printf("[Jaguar Core] Warning: SNI proxy start failed: %v", err)
		} else {
			if _, err := hostsMgr.Apply(sniProxy.BoundHost()); err != nil {
				log.Printf("[Jaguar Core] Warning: Hosts apply failed: %v", err)
			}
		}
	}

	// Initialize API Server
	apiServer := api.NewServer(eng, sniProxy, hostsMgr, dnsClient)
	httpServer := &http.Server{
		Addr:         fmt.Sprintf("127.0.0.1:%d", *port),
		Handler:      apiServer.Router(),
		ReadTimeout:  10 * time.Second,
		WriteTimeout: 10 * time.Second,
	}

	// Graceful shutdown channel
	stopChan := make(chan os.Signal, 1)
	signal.Notify(stopChan, os.Interrupt, syscall.SIGTERM)

	go func() {
		log.Printf("[Jaguar Core] API server listening at http://127.0.0.1:%d", *port)
		if err := httpServer.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("[Jaguar Core] HTTP server error: %v", err)
		}
	}()

	<-stopChan
	log.Println("[Jaguar Core] Shutdown signal received.")
	cleanup()
	log.Println("[Jaguar Core] Shutdown complete.")
}
