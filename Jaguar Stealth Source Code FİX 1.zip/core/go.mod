module jaguar-core

go 1.22
