Write-Host "======================================" -ForegroundColor Cyan
Write-Host " Building Jaguar Stealth Project      " -ForegroundColor Cyan
Write-Host "======================================" -ForegroundColor Cyan

# 1. Build Go Backend (Silent Windows GUI Subsystem)
Write-Host "[1/3] Building Go Core (jaguar-core.exe with -H=windowsgui)..." -ForegroundColor Yellow
Set-Location -Path "$PSScriptRoot\core"
go build -ldflags "-s -w -H=windowsgui" -o jaguar-core.exe ./cmd/main.go
if ($LASTEXITCODE -ne 0) {
    Write-Host "Go build failed!" -ForegroundColor Red
    exit 1
}
Copy-Item -Force .\jaguar-core.exe ..\ui\resources\bin\jaguar-core.exe
Write-Host "Go Core built successfully (Subsystem: Windows GUI, fully silent)." -ForegroundColor Green

# 2. Build UI Frontend & Electron
Write-Host "[2/3] Building Electron + React UI..." -ForegroundColor Yellow
Set-Location -Path "$PSScriptRoot\ui"
npm run build
if ($LASTEXITCODE -ne 0) {
    Write-Host "UI build failed!" -ForegroundColor Red
    exit 1
}

# 3. Package Portable and Setup Installers
Write-Host "[3/3] Packaging Portable and Setup NSIS Installers..." -ForegroundColor Yellow
npx electron-builder --win
if ($LASTEXITCODE -ne 0) {
    Write-Host "Packaging failed!" -ForegroundColor Red
    exit 1
}

Write-Host "======================================" -ForegroundColor Cyan
Write-Host " BUILD COMPLETED SUCCESSFULLY!        " -ForegroundColor Green
Write-Host " Check ui/release for:                " -ForegroundColor Cyan
Write-Host "  - Jaguar-Stealth-Setup-1.0.1.exe   " -ForegroundColor White
Write-Host "  - Jaguar-Stealth-Portable-1.0.1.exe" -ForegroundColor White
Write-Host "======================================" -ForegroundColor Cyan

