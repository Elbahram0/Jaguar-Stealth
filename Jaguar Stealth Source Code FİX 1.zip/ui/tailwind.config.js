/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/renderer/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        jaguar: {
          bg: '#0D0F12',
          card: '#16191E',
          surface: '#1F242C',
          border: '#2A313C',
          primary: '#10B981',
          accent: '#06B6D4',
          danger: '#EF4444',
          text: '#F3F4F6',
          muted: '#9CA3AF'
        }
      }
    },
  },
  plugins: [],
}