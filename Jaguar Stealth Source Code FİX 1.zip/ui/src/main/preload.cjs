const { contextBridge, ipcRenderer } = require('electron');

if (contextBridge && contextBridge.exposeInMainWorld) {
  contextBridge.exposeInMainWorld('jaguar', {
    getStatus: () => ipcRenderer.invoke('api:getStatus'),
    startService: () => ipcRenderer.invoke('api:startService'),
    stopService: () => ipcRenderer.invoke('api:stopService'),
    getDomains: () => ipcRenderer.invoke('api:getDomains'),
    addDomain: (domain) => ipcRenderer.invoke('api:addDomain', domain),
    updateConfig: (cfg) => ipcRenderer.invoke('api:updateConfig', cfg),
    resolveDNS: (domain) => ipcRenderer.invoke('api:resolveDNS', domain),
    minimizeWindow: () => ipcRenderer.send('window:minimize'),
    hideWindow: () => ipcRenderer.send('window:minimize'),
    closeWindow: () => ipcRenderer.send('app:quit'),
    quitApp: () => ipcRenderer.send('app:quit'),
    openExternal: (url) => ipcRenderer.send('app:openExternal', url),
    getAutoStart: () => ipcRenderer.invoke('app:getAutoStart'),
    setAutoStart: (enable) => ipcRenderer.invoke('app:setAutoStart', enable),
    getSettings: () => ipcRenderer.invoke('app:getSettings'),
    saveSettings: (settings) => ipcRenderer.invoke('app:saveSettings', settings),
  });
}