import { Tray, Menu, BrowserWindow, screen, nativeImage, app } from 'electron';
import * as path from 'path';
import * as fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export class TrayManager {
  private tray: Tray | null = null;
  private window: BrowserWindow;
  private hasCustomPosition = false;
  private isSystemMoving = false;

  private onQuit?: () => Promise<void> | void;

  constructor(window: BrowserWindow, onQuit?: () => Promise<void> | void) {
    this.window = window;
    this.onQuit = onQuit;
    
    // Remember when user drags or moves the window
    this.window.on('move', () => {
      if (!this.isSystemMoving) {
        this.hasCustomPosition = true;
      }
    });
  }

  public init() {
    const icon = this.createTrayIcon();
    this.tray = new Tray(icon);
    this.tray.setToolTip('Jaguar Stealth');

    this.tray.on('click', () => {
      this.toggleWindow();
    });

    this.tray.on('right-click', () => {
      const contextMenu = Menu.buildFromTemplate([
        {
          label: 'Open',
          click: () => this.showWindow(),
        },
        { type: 'separator' },
        {
          label: 'Quit',
          click: async () => {
            if (this.onQuit) {
              await this.onQuit();
            } else {
              app.quit();
            }
          },
        },
      ]);
      this.tray?.popUpContextMenu(contextMenu);
    });
  }

  public showWindow() {
    // If user hasn't moved the window, position it at bottom right
    if (!this.hasCustomPosition) {
      this.positionWindow();
    }
    this.window.show();
    this.window.focus();
  }

  public toggleWindow() {
    if (this.window.isVisible()) {
      this.window.hide();
    } else {
      this.showWindow();
    }
  }

  public positionWindow() {
    this.isSystemMoving = true;
    const primaryDisplay = screen.getPrimaryDisplay();
    const { workArea } = primaryDisplay;
    const width = 320;
    const height = 480;
    const margin = 12;

    // Fixed firmly at the bottom right of the work area
    const x = Math.round(workArea.x + workArea.width - width - margin);
    const y = Math.round(workArea.y + workArea.height - height - margin);

    this.window.setBounds({ x, y, width, height });
    setTimeout(() => {
      this.isSystemMoving = false;
    }, 150);
  }

  private createTrayIcon(): Electron.NativeImage {
    const candidates = [
      path.resolve(__dirname, '../../resources/logo.png'),
      path.resolve(__dirname, '../resources/logo.png'),
      path.resolve(__dirname, '../../logo.png'),
      path.resolve(__dirname, '../logo.png'),
      path.resolve(process.cwd(), 'resources/logo.png'),
      path.resolve(process.cwd(), 'ui/resources/logo.png'),
      path.resolve(process.cwd(), 'logo.png'),
      path.resolve(process.cwd(), 'ui/logo.png'),
      path.join(process.resourcesPath, 'resources', 'logo.png'),
      path.join(process.resourcesPath, 'logo.png'),
    ];

    for (const cand of candidates) {
      if (fs.existsSync(cand)) {
        try {
          const img = nativeImage.createFromPath(cand);
          if (!img.isEmpty()) {
            return img.resize({ width: 20, height: 20 });
          }
        } catch {
          // Ignore
        }
      }
    }

    const size = 16;
    const canvas = Buffer.alloc(size * size * 4);
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const dx = x - size / 2;
        const dy = y - size / 2;
        const dist = Math.sqrt(dx * dx + dy * dy);
        const idx = (y * size + x) * 4;
        if (dist <= 6) {
          canvas[idx] = 255;
          canvas[idx + 1] = 255;
          canvas[idx + 2] = 255;
          canvas[idx + 3] = 255;
        } else {
          canvas[idx + 3] = 0;
        }
      }
    }
    return nativeImage.createFromBuffer(canvas, { width: size, height: size });
  }
}