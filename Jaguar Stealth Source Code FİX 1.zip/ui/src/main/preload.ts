const { contextBridge, ipcRenderer } = require('electron');

const api = {
  getStatus: () => ipcRenderer.invoke('api:getStatus'),
  startService: () => ipcRenderer.invoke('api:startService'),
  stopService: () => ipcRenderer.invoke('api:stopService'),
  getDomains: () => ipcRenderer.invoke('api:getDomains'),
  addDomain: (domain: string) => ipcRenderer.invoke('api:addDomain', domain),
  updateConfig: (cfg: any) => ipcRenderer.invoke('api:updateConfig', cfg),
  resolveDNS: (domain: string) => ipcRenderer.invoke('api:resolveDNS', domain),
  minimizeWindow: () => ipcRenderer.send('window:minimize'),
  hideWindow: () => ipcRenderer.send('window:minimize'),
  closeWindow: () => ipcRenderer.send('app:quit'),
  quitApp: () => ipcRenderer.send('app:quit'),
  openExternal: (url: string) => ipcRenderer.send('app:openExternal', url),
  getAutoStart: () => ipcRenderer.invoke('app:getAutoStart'),
  setAutoStart: (enable: boolean) => ipcRenderer.invoke('app:setAutoStart', enable),
  getSettings: () => ipcRenderer.invoke('app:getSettings'),
  saveSettings: (settings: any) => ipcRenderer.invoke('app:saveSettings', settings),
};

contextBridge.exposeInMainWorld('jaguar', api);
export type JaguarAPI = typeof api;