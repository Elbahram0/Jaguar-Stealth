import { ChildProcess, spawn, execSync } from 'child_process';
import * as path from 'path';
import * as fs from 'fs';
import * as http from 'http';
import { fileURLToPath } from 'url';
import { app } from 'electron';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export class DaemonManager {
  private process: ChildProcess | null = null;
  private readonly port: number = 18231;

  public async ensureDaemonRunning(): Promise<boolean> {
    const isAlive = await this.pingAPI();
    if (isAlive) {
      console.log('[Daemon] jaguar-core is already running on port', this.port);
      return true;
    }

    return this.startDaemon();
  }

  public async startDaemon(): Promise<boolean> {
    const isDev = !app.isPackaged;
    
    let exePath = '';
    if (isDev) {
      const devCandidates = [
        path.resolve(__dirname, '../../../core/jaguar-core.exe'),
        path.resolve(process.cwd(), '../core/jaguar-core.exe'),
        path.resolve(process.cwd(), 'core/jaguar-core.exe'),
        path.resolve(process.cwd(), 'resources/bin/jaguar-core.exe'),
      ];
      for (const cand of devCandidates) {
        if (fs.existsSync(cand)) {
          exePath = cand;
          break;
        }
      }
    } else {
      const prodCandidates = [
        path.join(process.resourcesPath, 'bin', 'jaguar-core.exe'),
        path.join(path.dirname(process.execPath), 'resources', 'bin', 'jaguar-core.exe'),
        path.join(path.dirname(process.execPath), 'bin', 'jaguar-core.exe'),
        path.join(process.resourcesPath, 'jaguar-core.exe'),
      ];
      for (const cand of prodCandidates) {
        if (fs.existsSync(cand)) {
          exePath = cand;
          break;
        }
      }
    }

    if (!exePath || !fs.existsSync(exePath)) {
      console.error('[Daemon] jaguar-core.exe not found. Searched paths.');
      return false;
    }

    const exeDir = path.dirname(exePath);

    console.log('[Daemon] Starting jaguar-core at:', exePath);

    // 1. Direct spawn (instant & completely silent when running elevated)
    try {
      this.process = spawn(exePath, [`-port=${this.port}`, `-parent-pid=${process.pid}`], {
        cwd: exeDir,
        detached: false,
        stdio: 'ignore',
        windowsHide: true,
      });

      for (let i = 0; i < 6; i++) {
        await new Promise((r) => setTimeout(r, 250));
        if (await this.pingAPI()) {
          console.log('[Daemon] jaguar-core started directly and listening on port', this.port);
          return true;
        }
      }
    } catch (err) {
      console.warn('[Daemon] Direct spawn error:', err);
    }

    // 2. Fallback: Request Administrator elevation via hidden PowerShell RunAs
    console.log('[Daemon] Launching elevated fallback with Administrator privileges...');
    return new Promise((resolve) => {
      const psScript = `Start-Process -FilePath "${exePath}" -ArgumentList "-port=${this.port} -parent-pid=${process.pid}" -WorkingDirectory "${exeDir}" -Verb RunAs -WindowStyle Hidden`;
      const child = spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', psScript], {
        windowsHide: true,
        stdio: 'ignore',
      });

      child.on('close', async () => {
        // Poll for up to 6 seconds for the elevated backend to start listening
        for (let i = 0; i < 12; i++) {
          await new Promise((r) => setTimeout(r, 500));
          const alive = await this.pingAPI();
          if (alive) {
            console.log('[Daemon] Elevated jaguar-core is active and listening on port', this.port);
            resolve(true);
            return;
          }
        }
        resolve(false);
      });

      child.on('error', (err) => {
        console.error('[Daemon] Elevation error:', err);
        resolve(false);
      });
    });
  }

  public async stopDaemon(): Promise<void> {
    console.log('[Daemon] Sending graceful shutdown signal to jaguar-core...');
    await new Promise<void>((resolve) => {
      const req = http.request({
        hostname: '127.0.0.1',
        port: this.port,
        path: '/v1/shutdown',
        method: 'POST',
        timeout: 1000,
      }, (res) => {
        console.log('[Daemon] Core shutdown response:', res.statusCode);
        resolve();
      });
      req.on('error', () => resolve());
      req.on('timeout', () => {
        req.destroy();
        resolve();
      });
      req.end();
    });

    if (this.process) {
      try {
        this.process.kill();
      } catch {
        // Ignore
      }
      this.process = null;
    }

    // Short grace period
    await new Promise((r) => setTimeout(r, 200));

    // Fallback synchronous force kill using taskkill
    try {
      execSync('taskkill.exe /F /IM jaguar-core.exe /T', { stdio: 'ignore' });
    } catch {
      // Ignore
    }
  }

  public pingAPI(): Promise<boolean> {
    return new Promise((resolve) => {
      const req = http.get(`http://127.0.0.1:${this.port}/v1/status`, (res) => {
        resolve(res.statusCode === 200);
      });
      req.on('error', () => resolve(false));
      req.setTimeout(1000, () => {
        req.destroy();
        resolve(false);
      });
    });
  }
}