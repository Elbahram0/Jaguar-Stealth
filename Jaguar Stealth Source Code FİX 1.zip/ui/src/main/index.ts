import { app, BrowserWindow, ipcMain, screen, shell } from 'electron';
import { spawn, execSync } from 'child_process';
import * as path from 'path';
import * as fs from 'fs';
import { fileURLToPath } from 'url';
import { TrayManager } from './tray';
import { DaemonManager } from './daemon';

// Auto-elevate with Administrator privileges (required for WinDivert kernel driver)
function ensureElevated(): boolean {
  if (process.platform !== 'win32') return true;
  try {
    execSync('net session', { stdio: 'ignore' });
    return true;
  } catch {
    console.log('[Elevate] Process is not elevated. Requesting Administrator rights via UAC...');
    try {
      const exe = process.execPath;
      const args = process.argv.slice(1);
      const argsStr = args.map((a) => `"${a}"`).join(' ');
      const psScript = `Start-Process -FilePath "${exe}" ${argsStr ? `-ArgumentList '${argsStr}'` : ''} -Verb RunAs`;
      spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', psScript], {
        windowsHide: true,
        detached: true,
        stdio: 'ignore',
      }).unref();
    } catch (err) {
      console.error('[Elevate] Failed to relaunch elevated:', err);
    }
    return false;
  }
}

// In packaged distribution (Portable & Setup), always enforce Administrator rights
if (app.isPackaged && !ensureElevated()) {
  process.exit(0);
}

// Set application identity
app.name = 'Jaguar Stealth';
app.setName('Jaguar Stealth');
app.setAppUserModelId('com.jaguar.stealth');

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let mainWindow: BrowserWindow | null = null;
let trayManager: TrayManager | null = null;
let isQuitting = false;
const daemonManager = new DaemonManager();

// Single instance lock: strictly ensure ONLY 1 instance can ever run
const gotTheLock = app.requestSingleInstanceLock();
if (!gotTheLock) {
  // Terminate instantly so no secondary process ever stays running
  app.exit(0);
  process.exit(0);
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      trayManager?.positionWindow();
      if (!mainWindow.isVisible()) {
        mainWindow.show();
      }
      mainWindow.focus();
    }
  });
}

function createWindow(): BrowserWindow {
  const primaryDisplay = screen.getPrimaryDisplay();
  const { workArea } = primaryDisplay;
  const width = 320;
  const height = 480;
  const margin = 12;

  const x = Math.round(workArea.x + workArea.width - width - margin);
  const y = Math.round(workArea.y + workArea.height - height - margin);

  const iconCandidates = [
    path.join(process.resourcesPath, 'resources', 'logo.png'),
    path.join(process.resourcesPath, 'logo.png'),
    path.resolve(__dirname, '../../resources/logo.png'),
    path.resolve(__dirname, '../resources/logo.png'),
    path.resolve(process.cwd(), 'resources/logo.png'),
    path.resolve(process.cwd(), 'ui/resources/logo.png'),
  ];
  let windowIcon: string | undefined;
  for (const cand of iconCandidates) {
    if (fs.existsSync(cand)) {
      windowIcon = cand;
      break;
    }
  }

  mainWindow = new BrowserWindow({
    x,
    y,
    width,
    height,
    icon: windowIcon,
    show: false,
    frame: false,
    resizable: false,
    movable: true,
    skipTaskbar: true,
    alwaysOnTop: true,
    transparent: false,
    backgroundColor: '#000000',
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: false,
    },
  });

  if (process.env.VITE_DEV_SERVER_URL) {
    mainWindow.loadURL(process.env.VITE_DEV_SERVER_URL);
  } else {
    const htmlCandidates = [
      path.join(__dirname, '../../dist/index.html'),
      path.join(app.getAppPath(), 'dist/index.html'),
      path.join(__dirname, '../dist/index.html'),
      path.join(__dirname, 'index.html'),
    ];
    let loaded = false;
    for (const cand of htmlCandidates) {
      if (fs.existsSync(cand)) {
        console.log('[App] Loading UI HTML from:', cand);
        mainWindow.loadFile(cand);
        loaded = true;
        break;
      }
    }
    if (!loaded) {
      console.error('[App] ERROR: index.html not found among candidates:', htmlCandidates);
      mainWindow.loadFile(path.join(__dirname, '../../dist/index.html'));
    }
  }

  mainWindow.webContents.on('did-fail-load', (_event, errorCode, errorDescription) => {
    console.error('[App] Failed to load window content:', errorCode, errorDescription);
  });

  // Close event quits application and terminates backend completely
  mainWindow.on('close', (event) => {
    if (!isQuitting) {
      event.preventDefault();
      quitGracefully();
    }
  });

  mainWindow.once('ready-to-show', () => {
    if (mainWindow) {
      mainWindow.setBounds({ x, y, width, height });
      mainWindow.show();
    }
  });

  return mainWindow;
}

// REST API Helpers
const API_URL = 'http://127.0.0.1:18231';

async function fetchAPI(endpoint: string, options: RequestInit = {}) {
  try {
    const res = await fetch(`${API_URL}${endpoint}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(options.headers || {}),
      },
    });
    return await res.json();
  } catch (err: any) {
    return { success: false, error: err.message || 'API connection failed' };
  }
}

// Register IPC handlers
ipcMain.handle('api:getStatus', () => fetchAPI('/v1/status'));
ipcMain.handle('api:startService', () => fetchAPI('/v1/start', { method: 'POST' }));
ipcMain.handle('api:stopService', () => fetchAPI('/v1/stop', { method: 'POST' }));
ipcMain.handle('api:getDomains', () => fetchAPI('/v1/domains'));
ipcMain.handle('api:addDomain', (_event, domain: string) => fetchAPI('/v1/domains', {
  method: 'POST',
  body: JSON.stringify({ action: 'add', domain }),
}));

ipcMain.on('window:minimize', () => {
  mainWindow?.hide();
});

ipcMain.on('window:hide', () => {
  mainWindow?.hide();
});

// Persistent Settings Store (settings.json in userData)
interface AppSettings {
  theme: 'dark' | 'light';
  lang: string;
  autoStart: boolean;
  autoStopVal: string;
  autoStopUnit: 'sec' | 'min' | 'hour' | 'day';
  usageCount: number;
}

const defaultSettings: AppSettings = {
  theme: 'dark',
  lang: 'tr',
  autoStart: false,
  autoStopVal: '',
  autoStopUnit: 'min',
  usageCount: 0,
};

function getSettingsFilePath(): string {
  return path.join(app.getPath('userData'), 'settings.json');
}

function loadSettings(): AppSettings {
  try {
    const p = getSettingsFilePath();
    if (fs.existsSync(p)) {
      const content = fs.readFileSync(p, 'utf8');
      return { ...defaultSettings, ...JSON.parse(content) };
    }
  } catch (err) {
    console.error('[Settings] Error reading settings:', err);
  }
  return defaultSettings;
}

function saveSettings(partial: Partial<AppSettings>): AppSettings {
  try {
    const current = loadSettings();
    const updated = { ...current, ...partial };
    const p = getSettingsFilePath();
    fs.mkdirSync(path.dirname(p), { recursive: true });
    fs.writeFileSync(p, JSON.stringify(updated, null, 2), 'utf8');
    return updated;
  } catch (err) {
    console.error('[Settings] Error saving settings:', err);
    return defaultSettings;
  }
}

function updateWindowsAutoStart(enable: boolean) {
  try {
    // 1. Purge any stale/legacy 'electron' and 'electron.app.Electron' registry keys
    const cleanupCmd = `
      Remove-ItemProperty -Path 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run' -Name 'electron' -ErrorAction SilentlyContinue;
      Remove-ItemProperty -Path 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run' -Name 'electron.app.Electron' -ErrorAction SilentlyContinue;
    `;
    spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', cleanupCmd], { windowsHide: true });

    // 2. Set or remove native 'Jaguar Stealth' entry
    if (enable) {
      let target = `"${process.execPath}"`;
      if (!app.isPackaged) {
        target = `"${process.execPath}" "${path.resolve(process.cwd())}" --hidden`;
      } else {
        target = `"${process.execPath}" --hidden`;
      }
      const setCmd = `Set-ItemProperty -Path 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run' -Name 'Jaguar Stealth' -Value '${target}'`;
      spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', setCmd], { windowsHide: true });
    } else {
      const delCmd = `Remove-ItemProperty -Path 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run' -Name 'Jaguar Stealth' -ErrorAction SilentlyContinue`;
      spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', delCmd], { windowsHide: true });
    }
  } catch (err) {
    console.error('[AutoStart] Error updating Windows startup:', err);
  }
}

let isShuttingDown = false;

async function quitGracefully() {
  if (isShuttingDown) return;
  isShuttingDown = true;
  isQuitting = true;
  console.log('[App] Stopping engine and shutting down daemon cleanly...');
  try {
    await daemonManager.stopDaemon();
  } catch (err) {
    console.error('[App] Error during daemon stop:', err);
  }

  // Force kill any remaining jaguar-core processes
  try {
    execSync('taskkill.exe /F /IM jaguar-core.exe /T', { stdio: 'ignore' });
  } catch {
    // Ignore
  }

  app.exit(0);
  process.exit(0);
}

ipcMain.on('app:quit', () => {
  quitGracefully();
});

ipcMain.on('app:openExternal', (_event, url) => {
  if (typeof url === 'string' && (url.startsWith('https://') || url.startsWith('http://'))) {
    shell.openExternal(url);
  }
});

// Settings & Startup IPC Handlers
ipcMain.handle('app:getSettings', () => {
  return loadSettings();
});

ipcMain.handle('app:saveSettings', (_event, partial: Partial<AppSettings>) => {
  const updated = saveSettings(partial);
  if (partial.autoStart !== undefined) {
    updateWindowsAutoStart(partial.autoStart);
  }
  return updated;
});

ipcMain.handle('app:getAutoStart', () => {
  return loadSettings().autoStart;
});

ipcMain.handle('app:setAutoStart', (_event, enable: boolean) => {
  saveSettings({ autoStart: enable });
  updateWindowsAutoStart(enable);
  return enable;
});

app.whenReady().then(async () => {
  const win = createWindow();
  trayManager = new TrayManager(win, quitGracefully);
  trayManager.init();

  // Start Go Daemon asynchronously so window appears immediately
  console.log('[App] Starting Go core daemon...');
  daemonManager.ensureDaemonRunning().catch((err) => {
    console.error('[App] Daemon start error:', err);
  });
});

app.on('before-quit', (e) => {
  if (!isShuttingDown) {
    e.preventDefault();
    quitGracefully();
  }
});

app.on('window-all-closed', () => {
  if (process.platform !== 'win32') {
    app.quit();
  }
});