export function FlagTR({ className = "w-5 h-3.5" }: { className?: string }) {
  return (
    <svg className={`${className} rounded-xs shadow-xs shrink-0`} viewBox="0 0 1200 800" fill="none">
      <rect width="1200" height="800" fill="#E30A17" />
      <circle cx="425" cy="400" r="200" fill="#FFFFFF" />
      <circle cx="475" cy="400" r="160" fill="#E30A17" />
      <polygon
        fill="#FFFFFF"
        points="583,400 706,440 630,335 630,465 706,360"
        transform="rotate(-19 583 400)"
      />
    </svg>
  );
}

export function FlagGB({ className = "w-5 h-3.5" }: { className?: string }) {
  return (
    <svg className={`${className} rounded-xs shadow-xs shrink-0`} viewBox="0 0 60 30" fill="none">
      <clipPath id="s">
        <path d="M0,0 v30 h60 v-30 z"/>
      </clipPath>
      <clipPath id="t">
        <path d="M30,15 h30 v15 z v15 h-30 z h-30 v-15 z v-15 h30 z"/>
      </clipPath>
      <g clipPath="url(#s)">
        <path d="M0,0 v30 h60 v-30 z" fill="#012169"/>
        <path d="M0,0 L60,30 M60,0 L0,30" stroke="#fff" strokeWidth="6"/>
        <path d="M0,0 L60,30 M60,0 L0,30" clipPath="url(#t)" stroke="#C8102E" strokeWidth="4"/>
        <path d="M30,0 v30 M0,15 h60" stroke="#fff" strokeWidth="10"/>
        <path d="M30,0 v30 M0,15 h60" stroke="#C8102E" strokeWidth="6"/>
      </g>
    </svg>
  );
}

export function FlagRU({ className = "w-5 h-3.5" }: { className?: string }) {
  return (
    <svg className={`${className} rounded-xs shadow-xs shrink-0`} viewBox="0 0 9 6">
      <rect fill="#fff" width="9" height="6"/>
      <rect fill="#0039A6" y="2" width="9" height="4"/>
      <rect fill="#D52B1E" y="4" width="9" height="2"/>
    </svg>
  );
}

export function FlagCN({ className = "w-5 h-3.5" }: { className?: string }) {
  return (
    <svg className={`${className} rounded-xs shadow-xs shrink-0`} viewBox="0 0 900 600">
      <rect fill="#DE2910" width="900" height="600"/>
      <polygon fill="#FFDE00" points="150,50 168,107 228,107 179,142 198,198 150,163 102,198 121,142 72,107 132,107"/>
      <polygon fill="#FFDE00" points="300,40 304,53 318,53 306,61 311,74 300,66 289,74 294,61 282,53 296,53" transform="scale(1.5) translate(-100,-10)"/>
      <polygon fill="#FFDE00" points="360,80 364,93 378,93 366,101 371,114 360,106 349,114 354,101 342,93 356,93" transform="scale(1.5) translate(-140,-25)"/>
      <polygon fill="#FFDE00" points="360,160 364,173 378,173 366,181 371,194 360,186 349,194 354,181 342,173 356,173" transform="scale(1.5) translate(-140,-50)"/>
      <polygon fill="#FFDE00" points="300,220 304,233 318,233 306,241 311,254 300,246 289,254 294,241 282,233 296,233" transform="scale(1.5) translate(-100,-70)"/>
    </svg>
  );
}

export function FlagSA({ className = "w-5 h-3.5" }: { className?: string }) {
  return (
    <svg className={`${className} rounded-xs shadow-xs shrink-0`} viewBox="0 0 24 16">
      <rect width="24" height="16" fill="#006C35"/>
      <path d="M4 11h16v1H4z" fill="#FFFFFF"/>
      <circle cx="12" cy="7" r="2.5" fill="#FFFFFF"/>
      <circle cx="12" cy="7" r="1.8" fill="#006C35"/>
    </svg>
  );
}

export function FlagES({ className = "w-5 h-3.5" }: { className?: string }) {
  return (
    <svg className={`${className} rounded-xs shadow-xs shrink-0`} viewBox="0 0 750 500">
      <rect width="750" height="500" fill="#AA151B"/>
      <rect width="750" height="250" y="125" fill="#F1BF00"/>
    </svg>
  );
}