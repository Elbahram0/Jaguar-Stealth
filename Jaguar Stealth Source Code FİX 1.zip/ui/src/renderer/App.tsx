import { useState, useEffect, useCallback, useRef } from 'react';
import { Power, X, Minus, Settings, Moon, Sun, Globe, Info, Sliders, Timer, Play } from 'lucide-react';
import logoImg from './logo.png';
import { FlagTR, FlagGB, FlagRU, FlagCN, FlagSA, FlagES } from './components/Flags';
import { IconTelegram, IconYoutube, IconGithub } from './components/SocialIcons';

// Locales
import tr from './locales/tr.json';
import en from './locales/en.json';
import ru from './locales/ru.json';
import zh from './locales/zh.json';
import ar from './locales/ar.json';
import es from './locales/es.json';

type Lang = 'tr' | 'en' | 'ru' | 'zh' | 'ar' | 'es';

const locales: Record<Lang, typeof tr> = {
  tr,
  en,
  ru,
  zh,
  ar,
  es,
};

const languages: { code: Lang; label: string; Flag: (props: { className?: string }) => JSX.Element }[] = [
  { code: 'tr', label: 'Türkçe', Flag: FlagTR },
  { code: 'en', label: 'English', Flag: FlagGB },
  { code: 'ru', label: 'Русский', Flag: FlagRU },
  { code: 'zh', label: '中文', Flag: FlagCN },
  { code: 'ar', label: 'العربية', Flag: FlagSA },
  { code: 'es', label: 'Español', Flag: FlagES },
];

interface StatusData {
  running: boolean;
  version: string;
  uptime_sec: number;
  stats?: {
    is_running: boolean;
  };
}

const API_BASE = 'http://127.0.0.1:18231';

export default function App() {
  const [status, setStatus] = useState<StatusData | null>(null);
  const [loading, setLoading] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [settingsTab, setSettingsTab] = useState<'features' | 'lang' | 'about'>('features');
  
  // Language State
  const [lang, setLang] = useState<Lang>(() => {
    const saved = localStorage.getItem('jaguar_lang') as Lang;
    return saved && locales[saved] ? saved : 'tr';
  });

  const t = (key: keyof typeof tr): string => {
    return locales[lang]?.[key] || tr[key] || '';
  };

  const handleLangChange = (newLang: Lang) => {
    setLang(newLang);
    localStorage.setItem('jaguar_lang', newLang);
    if (window.jaguar && typeof (window.jaguar as any).saveSettings === 'function') {
      (window.jaguar as any).saveSettings({ lang: newLang });
    }
  };

  // Theme State ('dark' | 'light')
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    return (localStorage.getItem('jaguar_theme') as 'dark' | 'light') || 'dark';
  });

  const isDark = theme === 'dark';

  const handleThemeChange = (newTheme: 'dark' | 'light') => {
    setTheme(newTheme);
    localStorage.setItem('jaguar_theme', newTheme);
    if (window.jaguar && typeof (window.jaguar as any).saveSettings === 'function') {
      (window.jaguar as any).saveSettings({ theme: newTheme });
    }
  };

  // Windows Startup State
  const [autoStart, setAutoStart] = useState(false);

  // Manual Auto-stop timer state: user enters a number + selects unit (sec, min, hour, day)
  const [autoStopVal, setAutoStopVal] = useState<string>(() => {
    return localStorage.getItem('jaguar_auto_stop_val') || '';
  });

  const [autoStopUnit, setAutoStopUnit] = useState<'sec' | 'min' | 'hour' | 'day'>(() => {
    const saved = localStorage.getItem('jaguar_auto_stop_unit');
    return (saved as 'sec' | 'min' | 'hour' | 'day') || 'min';
  });

  const [autoStopRemaining, setAutoStopRemaining] = useState<number | null>(null);
  const targetEndTimeRef = useRef<number | null>(null);

  // Connection duration & usage count
  const [durationSec, setDurationSec] = useState(0);
  const [usageCount, setUsageCount] = useState<number>(() => {
    const saved = localStorage.getItem('jaguar_usage_count');
    return saved ? parseInt(saved, 10) : 0;
  });

  // Custom Domain input state
  const [customDomainInput, setCustomDomainInput] = useState('');
  const [domainAddedMsg, setDomainAddedMsg] = useState('');

  const handleAddDomain = async () => {
    const clean = customDomainInput.trim().toLowerCase();
    if (!clean) return;
    if (window.jaguar && typeof (window.jaguar as any).addDomain === 'function') {
      await (window.jaguar as any).addDomain(clean);
      setCustomDomainInput('');
      setDomainAddedMsg('Eklendi!');
      setTimeout(() => setDomainAddedMsg(''), 2000);
      fetchStatus();
    }
  };

  // Load all persisted settings from disk on initial mount
  useEffect(() => {
    const init = async () => {
      try {
        if (window.jaguar && typeof (window.jaguar as any).getSettings === 'function') {
          const s = await (window.jaguar as any).getSettings();
          if (s) {
            if (s.theme) {
              setTheme(s.theme);
              localStorage.setItem('jaguar_theme', s.theme);
            }
            if (s.lang) {
              setLang(s.lang);
              localStorage.setItem('jaguar_lang', s.lang);
            }
            if (s.autoStart !== undefined) {
              setAutoStart(!!s.autoStart);
            }
            if (s.autoStopVal !== undefined) {
              setAutoStopVal(s.autoStopVal);
              localStorage.setItem('jaguar_auto_stop_val', s.autoStopVal);
            }
            if (s.autoStopUnit) {
              setAutoStopUnit(s.autoStopUnit);
              localStorage.setItem('jaguar_auto_stop_unit', s.autoStopUnit);
            }
            if (s.usageCount !== undefined) {
              setUsageCount(s.usageCount);
              localStorage.setItem('jaguar_usage_count', s.usageCount.toString());
            }
          }
        }
      } catch (err) {
        console.error('Settings load error:', err);
      }
    };
    init();
  }, []);

  const handleAutoStartToggle = async () => {
    const next = !autoStart;
    setAutoStart(next);
    if (window.jaguar && typeof (window.jaguar as any).setAutoStart === 'function') {
      await (window.jaguar as any).setAutoStart(next);
    }
  };

  const getUnitMultiplier = (u: 'sec' | 'min' | 'hour' | 'day') => {
    switch (u) {
      case 'sec': return 1;
      case 'min': return 60;
      case 'hour': return 3600;
      case 'day': return 86400;
      default: return 60;
    }
  };

  const handleAutoStopTimeChange = (newVal: string, newUnit: 'sec' | 'min' | 'hour' | 'day') => {
    const cleaned = newVal.replace(/[^0-9]/g, '').slice(0, 5);
    setAutoStopVal(cleaned);
    setAutoStopUnit(newUnit);
    localStorage.setItem('jaguar_auto_stop_val', cleaned);
    localStorage.setItem('jaguar_auto_stop_unit', newUnit);
    if (window.jaguar && typeof (window.jaguar as any).saveSettings === 'function') {
      (window.jaguar as any).saveSettings({ autoStopVal: cleaned, autoStopUnit: newUnit });
    }
  };

  const fetchStatus = useCallback(async () => {
    try {
      if (window.jaguar && typeof window.jaguar.getStatus === 'function') {
        const res = await window.jaguar.getStatus();
        if (res && res.running !== undefined) {
          setStatus(res);
          return;
        }
      }
      const resp = await fetch(`${API_BASE}/v1/status`);
      if (resp.ok) {
        const data = await resp.json();
        setStatus(data);
      }
    } catch {
      // Backend polling
    }
  }, []);

  useEffect(() => {
    fetchStatus();
    const interval = setInterval(fetchStatus, 1000);
    return () => clearInterval(interval);
  }, [fetchStatus]);

  const isConnected = status?.running || status?.stats?.is_running || false;

  // Smart usage tracking: only count as a valid usage session if connection stays active for >= 15 seconds
  const sessionTimerRef = useRef<NodeJS.Timeout | null>(null);
  const sessionCountedRef = useRef(false);

  useEffect(() => {
    if (isConnected) {
      if (!sessionCountedRef.current && !sessionTimerRef.current) {
        sessionTimerRef.current = setTimeout(() => {
          sessionCountedRef.current = true;
          setUsageCount((prev) => {
            const next = prev + 1;
            localStorage.setItem('jaguar_usage_count', next.toString());
            if (window.jaguar && typeof (window.jaguar as any).saveSettings === 'function') {
              (window.jaguar as any).saveSettings({ usageCount: next });
            }
            return next;
          });
        }, 15000);
      }
    } else {
      if (sessionTimerRef.current) {
        clearTimeout(sessionTimerRef.current);
        sessionTimerRef.current = null;
      }
      sessionCountedRef.current = false;
    }

    return () => {
      if (sessionTimerRef.current) {
        clearTimeout(sessionTimerRef.current);
        sessionTimerRef.current = null;
      }
    };
  }, [isConnected]);

  // Duration timer
  useEffect(() => {
    let timer: any = null;
    if (isConnected) {
      timer = setInterval(() => {
        setDurationSec((prev) => prev + 1);
      }, 1000);
    } else {
      setDurationSec(0);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isConnected]);

  const formatDuration = (totalSeconds: number) => {
    const hrs = Math.floor(totalSeconds / 3600);
    const mins = Math.floor((totalSeconds % 3600) / 60);
    const secs = totalSeconds % 60;
    const pad = (n: number) => n.toString().padStart(2, '0');
    if (hrs > 0) {
      return `${pad(hrs)}:${pad(mins)}:${pad(secs)}`;
    }
    return `${pad(mins)}:${pad(secs)}`;
  };

  const formatAutoStopRemaining = (totalSec: number) => {
    if (totalSec <= 0) return '00:00';
    const days = Math.floor(totalSec / 86400);
    const remAfterDays = totalSec % 86400;
    const hrs = Math.floor(remAfterDays / 3600);
    const mins = Math.floor((remAfterDays % 3600) / 60);
    const secs = remAfterDays % 60;
    const pad = (n: number) => n.toString().padStart(2, '0');
    if (days > 0) {
      return `${days}d ${pad(hrs)}:${pad(mins)}:${pad(secs)}`;
    }
    if (hrs > 0) {
      return `${pad(hrs)}:${pad(mins)}:${pad(secs)}`;
    }
    return `${pad(mins)}:${pad(secs)}`;
  };

  const toggleService = async (options?: { keepTimer?: boolean } | unknown) => {
    const keepTimer = !!(options && typeof options === 'object' && 'keepTimer' in options && (options as any).keepTimer);
    if (!keepTimer) {
      targetEndTimeRef.current = null;
      setAutoStopRemaining(null);
    }

    setLoading(true);
    try {
      if (isConnected) {
        if (window.jaguar && typeof window.jaguar.stopService === 'function') {
          await window.jaguar.stopService();
        } else {
          await fetch(`${API_BASE}/v1/stop`, { method: 'POST' });
        }
      } else {
        if (window.jaguar && typeof window.jaguar.startService === 'function') {
          await window.jaguar.startService();
        } else {
          await fetch(`${API_BASE}/v1/start`, { method: 'POST' });
        }
      }
      await fetchStatus();
    } catch (err) {
      console.error('Toggle error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleStartTimerAndGoHome = async () => {
    const num = parseInt(autoStopVal, 10);
    if (!isNaN(num) && num > 0) {
      const mult = getUnitMultiplier(autoStopUnit);
      targetEndTimeRef.current = Date.now() + num * mult * 1000;
      setAutoStopRemaining(num * mult);
    } else {
      targetEndTimeRef.current = null;
      setAutoStopRemaining(null);
    }

    if (!isConnected) {
      await toggleService({ keepTimer: true });
    }
    setShowSettings(false);
  };

  // When connection drops, clear any pending auto-stop timers
  useEffect(() => {
    if (!isConnected) {
      targetEndTimeRef.current = null;
      setAutoStopRemaining(null);
    }
  }, [isConnected]);

  // Auto-stop countdown ticker and disconnect trigger
  useEffect(() => {
    if (!isConnected) {
      setAutoStopRemaining(null);
      return;
    }

    const timer = setInterval(() => {
      if (targetEndTimeRef.current) {
        const diffMs = targetEndTimeRef.current - Date.now();
        const remainingSec = Math.max(0, Math.ceil(diffMs / 1000));
        setAutoStopRemaining(remainingSec);
        if (remainingSec <= 0) {
          targetEndTimeRef.current = null;
          setAutoStopRemaining(null);
          toggleService();
        }
      } else {
        setAutoStopRemaining(null);
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [isConnected]);

  const handleMinimize = () => {
    if (window.jaguar && typeof (window.jaguar as any).minimizeWindow === 'function') {
      (window.jaguar as any).minimizeWindow();
    } else if (window.jaguar && typeof window.jaguar.hideWindow === 'function') {
      window.jaguar.hideWindow();
    }
  };

  const handleClose = () => {
    if (window.jaguar && typeof (window.jaguar as any).closeWindow === 'function') {
      (window.jaguar as any).closeWindow();
    } else if (window.jaguar && typeof window.jaguar.quitApp === 'function') {
      window.jaguar.quitApp();
    } else {
      window.close();
    }
  };

  const openLink = (url: string) => {
    if (window.jaguar && typeof (window.jaguar as any).openExternal === 'function') {
      (window.jaguar as any).openExternal(url);
    } else {
      window.open(url, '_blank');
    }
  };

  return (
    <div 
      style={{ WebkitAppRegion: 'drag' } as React.CSSProperties}
      className={`w-[320px] h-[480px] shadow-2xl flex flex-col justify-between p-5 select-none relative font-sans overflow-hidden transition-colors duration-300 cursor-default ${
        isDark 
          ? 'bg-[#000000] text-[#FFFFFF] border border-[#1f242e]' 
          : 'bg-[#FFFFFF] text-[#111827] border border-[#E5E7EB]'
      }`}
    >
      
      {/* Top Header (Draggable) */}
      <div 
        style={{ WebkitAppRegion: 'drag' } as React.CSSProperties}
        className={`flex items-center justify-between pb-3 border-b transition-colors duration-300 select-none ${
          isDark ? 'border-[#181d26]' : 'border-[#E5E7EB]'
        }`}
      >
        <div 
          style={{ WebkitAppRegion: 'drag' } as React.CSSProperties}
          className="flex items-center space-x-2 cursor-grab active:cursor-grabbing min-w-0"
        >
          <img 
            src={logoImg} 
            alt="Jaguar Logo" 
            className="h-8 w-auto max-w-[40px] object-contain drop-shadow select-none shrink-0"
          />
          <h1 className={`font-black text-xs tracking-wider uppercase whitespace-nowrap leading-none select-none ${
            isDark ? 'text-[#FFFFFF]' : 'text-[#111827]'
          }`}>
            {t('appTitle')}
          </h1>
        </div>

        <div 
          style={{ WebkitAppRegion: 'no-drag' } as React.CSSProperties}
          className="flex items-center space-x-1 shrink-0 pointer-events-auto"
        >
          {/* Settings Button */}
          <button 
            style={{ WebkitAppRegion: 'no-drag' } as React.CSSProperties}
            onClick={() => setShowSettings(!showSettings)}
            className={`p-1 rounded-md transition-all cursor-pointer border ${
              isDark 
                ? (showSettings ? 'bg-[#1f2633] border-[#3b82f6] text-[#FFFFFF]' : 'hover:bg-[#1f242e] bg-[#111620] border-[#262d3a] text-[#FFFFFF]')
                : (showSettings ? 'bg-[#E5E7EB] border-[#D1D5DB] text-[#111827]' : 'hover:bg-[#F3F4F6] bg-[#F9FAFB] border-[#E5E7EB] text-[#111827]')
            }`}
            title={t('settings')}
          >
            <Settings className="w-3.5 h-3.5" />
          </button>

          {/* Minimize Button (Küçült) */}
          <button 
            style={{ WebkitAppRegion: 'no-drag' } as React.CSSProperties}
            onClick={handleMinimize}
            className={`p-1 rounded-md transition-all cursor-pointer border ${
              isDark 
                ? 'hover:bg-[#1f242e] bg-[#111620] border-[#262d3a] text-[#FFFFFF]' 
                : 'hover:bg-[#F3F4F6] bg-[#F9FAFB] border-[#E5E7EB] text-[#111827]'
            }`}
            title="Küçült (Tepsiye Gizle)"
          >
            <Minus className="w-3.5 h-3.5" />
          </button>

          {/* Close Button */}
          <button 
            style={{ WebkitAppRegion: 'no-drag' } as React.CSSProperties}
            onClick={handleClose}
            className={`p-1 rounded-md transition-all cursor-pointer border ${
              isDark 
                ? 'hover:bg-[#1f242e] bg-[#111620] border-[#262d3a] text-[#FFFFFF]' 
                : 'hover:bg-[#F3F4F6] bg-[#F9FAFB] border-[#E5E7EB] text-[#111827]'
            }`}
            title="Kapat"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Center 1-Click Power Area (Background Draggable) */}
      <div 
        style={{ WebkitAppRegion: 'drag' } as React.CSSProperties}
        className="flex flex-col items-center justify-center my-auto space-y-6 cursor-grab active:cursor-grabbing"
      >
        
        {/* Status Pill: BAGLI / BAGLI DEGIL */}
        <div 
          style={{ WebkitAppRegion: 'no-drag' } as React.CSSProperties}
          className={`px-3.5 py-1 rounded-full border flex items-center space-x-1.5 transition-all duration-300 max-w-[240px] cursor-default ${
            isConnected 
              ? (isDark ? 'bg-[#10b981]/15 border-[#10b981] text-[#FFFFFF]' : 'bg-[#10b981]/15 border-[#10b981] text-[#111827]')
              : (isDark ? 'bg-[#ef4444]/15 border-[#ef4444] text-[#FFFFFF]' : 'bg-[#ef4444]/15 border-[#ef4444] text-[#111827]')
          }`}
        >
          <span className={`w-2 h-2 rounded-full shrink-0 ${isConnected ? 'bg-[#10b981] animate-ping' : 'bg-[#ef4444]'}`} />
          <span className="text-[11px] font-black tracking-wide uppercase truncate">
            {isConnected ? t('connected') : t('disconnected')}
          </span>
        </div>

        {/* Big Power Switch Button */}
        <button
          style={{ WebkitAppRegion: 'no-drag' } as React.CSSProperties}
          onClick={() => toggleService()}
          disabled={loading}
          className={`w-36 h-36 rounded-full flex items-center justify-center transition-all duration-500 cursor-pointer relative ${
            isConnected 
              ? (isDark 
                  ? 'bg-[#064e3b] border-4 border-[#10b981] shadow-[0_0_45px_rgba(16,185,129,0.5)]' 
                  : 'bg-[#DCFCE7] border-4 border-[#10b981] shadow-[0_0_35px_rgba(16,185,129,0.35)]')
              : (isDark 
                  ? 'bg-[#111620] border-4 border-[#2b3342] hover:border-[#404c60]' 
                  : 'bg-[#F3F4F6] border-4 border-[#E5E7EB] hover:border-[#D1D5DB]')
          }`}
        >
          <Power className={`w-14 h-14 transition-transform duration-300 ${
            loading ? 'animate-spin' : ''
          } ${
            isConnected 
              ? 'text-[#10b981]' 
              : (isDark ? 'text-[#FFFFFF]' : 'text-[#6B7280]')
          }`} />
        </button>

      </div>

      {/* Bottom Stats: Duration & Usage Count (Cards no-drag, container draggable) */}
      <div 
        style={{ WebkitAppRegion: 'drag' } as React.CSSProperties}
        className="grid grid-cols-2 gap-2.5 cursor-grab active:cursor-grabbing"
      >
        {/* Connection Duration */}
        <div 
          style={{ WebkitAppRegion: 'no-drag' } as React.CSSProperties}
          className={`border rounded-xl p-3 flex flex-col justify-between transition-colors duration-300 min-w-0 overflow-hidden cursor-default ${
            isDark 
              ? 'bg-[#0e121a] border-[#1f2634]' 
              : 'bg-[#F9FAFB] border-[#E5E7EB]'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className={`text-[10px] uppercase font-bold tracking-tight truncate ${
              isDark ? 'text-[#9CA3AF]' : 'text-[#6B7280]'
            }`} title={t('duration')}>
              {t('duration')}
            </span>
            {autoStopRemaining !== null && (
              <span className="text-[9px] font-mono font-bold text-amber-400 shrink-0 flex items-center space-x-1">
                <Timer className="w-2.5 h-2.5 animate-pulse" />
                <span>{formatAutoStopRemaining(autoStopRemaining)}</span>
              </span>
            )}
          </div>
          <span className={`text-lg font-mono font-black mt-1 tracking-wider truncate ${
            isDark ? 'text-[#FFFFFF]' : 'text-[#111827]'
          }`}>
            {formatDuration(durationSec)}
          </span>
        </div>

        {/* Usage Count */}
        <div 
          style={{ WebkitAppRegion: 'no-drag' } as React.CSSProperties}
          className={`border rounded-xl p-3 flex flex-col justify-between transition-colors duration-300 min-w-0 overflow-hidden cursor-default ${
            isDark 
              ? 'bg-[#0e121a] border-[#1f2634]' 
              : 'bg-[#F9FAFB] border-[#E5E7EB]'
          }`}
        >
          <span className={`text-[10px] uppercase font-bold tracking-tight truncate block ${
            isDark ? 'text-[#9CA3AF]' : 'text-[#6B7280]'
          }`} title={t('usageCount')}>
            {t('usageCount')}
          </span>
          <span className={`text-lg font-mono font-black mt-1 truncate ${
            isDark ? 'text-[#FFFFFF]' : 'text-[#111827]'
          }`}>
            {usageCount} {t('timesUnit')}
          </span>
        </div>
      </div>

      {/* Left-Side Settings Drawer (3 Pages: Tema, Dil, Hakkında) */}
      <div 
        style={{ WebkitAppRegion: 'no-drag' } as React.CSSProperties}
        className={`absolute top-0 left-0 bottom-0 w-[260px] z-50 p-4 flex flex-col justify-between transition-transform duration-300 shadow-2xl border-r ${
          showSettings ? 'translate-x-0' : '-translate-x-full'
        } ${
          isDark 
            ? 'bg-[#0a0d14] border-[#1f2634] text-[#FFFFFF]' 
            : 'bg-[#FFFFFF] border-[#E5E7EB] text-[#111827]'
        }`}
      >
        
        <div className="space-y-4">
          {/* Drawer Top */}
          <div className="flex items-center justify-between pb-2 border-b border-inherit">
            <h2 className="font-extrabold text-xs tracking-wider uppercase">
              {t('settings')}
            </h2>

            <button 
              style={{ WebkitAppRegion: 'no-drag' } as React.CSSProperties}
              onClick={() => setShowSettings(false)}
              className={`p-1.5 rounded-lg transition-colors cursor-pointer border ${
                isDark 
                  ? 'hover:bg-[#1a202c] bg-[#111620] border-[#262d3a] text-[#9CA3AF] hover:text-[#FFFFFF]' 
                  : 'hover:bg-[#E5E7EB] bg-[#F3F4F6] border-[#D1D5DB] text-[#6B7280] hover:text-[#111827]'
              }`}
              title="Kapat"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* 3-Page Selector Tabs (Özellik / Dil / Hakkında) */}
          <div className={`grid grid-cols-3 p-1 rounded-xl border ${
            isDark ? 'bg-[#111620] border-[#1f2634]' : 'bg-[#F3F4F6] border-[#E5E7EB]'
          }`}>
            <button
              onClick={() => setSettingsTab('features')}
              className={`py-1.5 px-1 rounded-lg text-[10px] font-bold transition-all flex items-center justify-center space-x-1 cursor-pointer min-w-0 overflow-hidden ${
                settingsTab === 'features'
                  ? (isDark ? 'bg-[#1f2633] text-[#FFFFFF] shadow-sm' : 'bg-[#FFFFFF] text-[#111827] shadow-sm')
                  : (isDark ? 'text-[#9CA3AF] hover:text-[#FFFFFF]' : 'text-[#6B7280] hover:text-[#111827]')
              }`}
            >
              <Sliders className="w-3 h-3 shrink-0" />
              <span className="truncate">{t('features')}</span>
            </button>

            <button
              onClick={() => setSettingsTab('lang')}
              className={`py-1.5 px-1 rounded-lg text-[10px] font-bold transition-all flex items-center justify-center space-x-1 cursor-pointer min-w-0 overflow-hidden ${
                settingsTab === 'lang'
                  ? (isDark ? 'bg-[#1f2633] text-[#FFFFFF] shadow-sm' : 'bg-[#FFFFFF] text-[#111827] shadow-sm')
                  : (isDark ? 'text-[#9CA3AF] hover:text-[#FFFFFF]' : 'text-[#6B7280] hover:text-[#111827]')
              }`}
            >
              <Globe className="w-3 h-3 shrink-0" />
              <span className="truncate">{t('language')}</span>
            </button>

            <button
              onClick={() => setSettingsTab('about')}
              className={`py-1.5 px-1 rounded-lg text-[10px] font-bold transition-all flex items-center justify-center space-x-1 cursor-pointer min-w-0 overflow-hidden ${
                settingsTab === 'about'
                  ? (isDark ? 'bg-[#1f2633] text-[#FFFFFF] shadow-sm' : 'bg-[#FFFFFF] text-[#111827] shadow-sm')
                  : (isDark ? 'text-[#9CA3AF] hover:text-[#FFFFFF]' : 'text-[#6B7280] hover:text-[#111827]')
              }`}
            >
              <Info className="w-3 h-3 shrink-0" />
              <span className="truncate">{t('about')}</span>
            </button>
          </div>

          {/* Page 1: Özellikler (Features, Theme, Auto-stop & Reset) */}
          {settingsTab === 'features' && (
            <div className="space-y-3 pt-1 max-h-[340px] overflow-y-auto pr-1">
              {/* Theme Selection */}
              <div className="space-y-1.5">
                <span className={`text-[10px] uppercase font-bold tracking-wider ${
                  isDark ? 'text-[#9CA3AF]' : 'text-[#6B7280]'
                }`}>
                  {t('theme')}
                </span>

                <div className="grid grid-cols-2 gap-2">
                  {/* Gece (Dark) */}
                  <button
                    onClick={() => handleThemeChange('dark')}
                    className={`py-2 px-2 rounded-xl border flex items-center justify-center space-x-1.5 transition-all cursor-pointer ${
                      isDark 
                        ? 'bg-[#161c28] border-[#3b82f6] text-[#FFFFFF] shadow-sm' 
                        : 'bg-[#F9FAFB] border-[#E5E7EB] text-[#6B7280] hover:bg-[#F3F4F6]'
                    }`}
                  >
                    <Moon className="w-3.5 h-3.5" />
                    <span className="text-[11px] font-bold">{t('night')}</span>
                  </button>

                  {/* Gündüz (Light) */}
                  <button
                    onClick={() => handleThemeChange('light')}
                    className={`py-2 px-2 rounded-xl border flex items-center justify-center space-x-1.5 transition-all cursor-pointer ${
                      !isDark 
                        ? 'bg-[#EFF6FF] border-[#3b82f6] text-[#1D4ED8] shadow-sm' 
                        : 'bg-[#111620] border-[#1f2634] text-[#9CA3AF] hover:bg-[#161c28]'
                    }`}
                  >
                    <Sun className="w-3.5 h-3.5" />
                    <span className="text-[11px] font-bold">{t('day')}</span>
                  </button>
                </div>
              </div>

              {/* Startup Toggle */}
              <div className="pt-2 border-t border-inherit">
                <button
                  onClick={handleAutoStartToggle}
                  className={`w-full p-2.5 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                    isDark 
                      ? 'bg-[#111620] border-[#1f2634] hover:bg-[#161c28]' 
                      : 'bg-[#F9FAFB] border-[#E5E7EB] hover:bg-[#F3F4F6]'
                  }`}
                >
                  <span className={`text-xs font-bold ${isDark ? 'text-[#FFFFFF]' : 'text-[#111827]'}`}>
                    {t('autoStart')}
                  </span>
                  <div className={`w-9 h-5 rounded-full transition-colors relative flex items-center px-0.5 ${
                    autoStart ? 'bg-[#10b981]' : (isDark ? 'bg-[#2b3342]' : 'bg-[#D1D5DB]')
                  }`}>
                    <div className={`w-4 h-4 rounded-full bg-white shadow transition-transform ${
                      autoStart ? 'translate-x-4' : 'translate-x-0'
                    }`} />
                  </div>
                </button>
              </div>

              {/* Auto-Stop / Sleep Timer */}
              <div className="space-y-1.5 pt-2 border-t border-inherit">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-1.5 min-w-0">
                    <span className={`text-[10px] uppercase font-bold tracking-wider truncate ${
                      isDark ? 'text-[#9CA3AF]' : 'text-[#6B7280]'
                    }`}>
                      {t('autoStop')}
                    </span>
                    {autoStopRemaining !== null && (
                      <span className="text-[9px] font-mono font-bold text-amber-400 shrink-0 flex items-center space-x-1">
                        <Timer className="w-2.5 h-2.5 animate-pulse" />
                        <span>{formatAutoStopRemaining(autoStopRemaining)}</span>
                      </span>
                    )}
                  </div>

                  {/* Sağda yazma yeri */}
                  <input
                    type="text"
                    inputMode="numeric"
                    pattern="[0-9]*"
                    value={autoStopVal}
                    onChange={(e) => handleAutoStopTimeChange(e.target.value, autoStopUnit)}
                    placeholder="0"
                    className={`w-16 py-1 px-2 text-center text-xs font-bold rounded-lg border outline-none transition-all ${
                      isDark 
                        ? 'bg-[#111620] border-[#1f2634] text-white focus:border-[#10b981] placeholder-zinc-600' 
                        : 'bg-[#F9FAFB] border-[#E5E7EB] text-black focus:border-[#10b981] placeholder-zinc-400'
                    }`}
                  />
                </div>

                {/* Alttada açılan pencere (dropdown: saniye, dakika, saat, gün) */}
                <div className="relative">
                  <select
                    value={autoStopUnit}
                    onChange={(e) => handleAutoStopTimeChange(autoStopVal, e.target.value as any)}
                    className={`w-full py-2 px-3 pr-8 rounded-xl border text-xs font-bold transition-all cursor-pointer appearance-none outline-none ${
                      isDark 
                        ? 'bg-[#111620] border-[#1f2634] text-white hover:border-[#2b3548] focus:border-[#10b981]' 
                        : 'bg-[#F9FAFB] border-[#E5E7EB] text-[#111827] hover:border-[#D1D5DB] focus:border-[#10b981]'
                    }`}
                  >
                    <option value="sec" className={isDark ? 'bg-[#111620] text-white' : 'bg-white text-black'}>{t('unitSecFull')}</option>
                    <option value="min" className={isDark ? 'bg-[#111620] text-white' : 'bg-white text-black'}>{t('unitMinFull')}</option>
                    <option value="hour" className={isDark ? 'bg-[#111620] text-white' : 'bg-white text-black'}>{t('unitHourFull')}</option>
                    <option value="day" className={isDark ? 'bg-[#111620] text-white' : 'bg-white text-black'}>{t('unitDayFull')}</option>
                  </select>
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-zinc-400 text-[10px]">
                    ▼
                  </div>
                </div>

                {/* Başlat Butonu (Ana Menüye Atar & Bağlantıyı/Geri Sayımı Başlatır) */}
                <button
                  type="button"
                  onClick={handleStartTimerAndGoHome}
                  className="w-full mt-2 py-2 px-3 rounded-xl bg-[#10b981] hover:bg-[#059669] active:scale-[0.98] text-white text-xs font-black flex items-center justify-center space-x-2 transition-all shadow-md shadow-[#10b981]/25 cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span className="tracking-wider uppercase">{t('startTimer')}</span>
                </button>
              </div>

              {/* Global Domain Section */}
              <div className="space-y-2 pt-2 border-t border-inherit">
                <div className="flex items-center justify-between">
                  <span className={`text-[10px] uppercase font-bold tracking-wider ${
                    isDark ? 'text-[#9CA3AF]' : 'text-[#6B7280]'
                  }`}>
                    Global Koruma ({(status as any)?.total_domains || 44} Domain)
                  </span>
                  {domainAddedMsg && (
                    <span className="text-[10px] font-bold text-emerald-400 animate-pulse">
                      {domainAddedMsg}
                    </span>
                  )}
                </div>

                <div className="flex space-x-1.5">
                  <input
                    type="text"
                    value={customDomainInput}
                    onChange={(e) => setCustomDomainInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleAddDomain()}
                    placeholder="ornek-site.com"
                    className={`flex-1 py-1.5 px-2.5 text-xs font-semibold rounded-lg border outline-none transition-all ${
                      isDark 
                        ? 'bg-[#111620] border-[#1f2634] text-white focus:border-[#10b981] placeholder-zinc-600' 
                        : 'bg-[#F9FAFB] border-[#E5E7EB] text-black focus:border-[#10b981] placeholder-zinc-400'
                    }`}
                  />
                  <button
                    type="button"
                    onClick={handleAddDomain}
                    className="py-1.5 px-3 rounded-lg bg-[#3b82f6] hover:bg-[#2563eb] text-white text-xs font-bold transition-all shrink-0 cursor-pointer shadow-sm"
                  >
                    + Ekle
                  </button>
                </div>

                <div className="flex flex-wrap gap-1 pt-0.5">
                  {['Discord', 'Roblox', 'Twitter/X', 'Wattpad', 'Imgur'].map((p) => (
                    <span
                      key={p}
                      className={`text-[9px] font-bold px-2 py-0.5 rounded-md border ${
                        isDark 
                          ? 'bg-[#111620] border-[#1f2634] text-zinc-300' 
                          : 'bg-[#F3F4F6] border-[#E5E7EB] text-zinc-700'
                      }`}
                    >
                      ✓ {p}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Page 2: Dil (Language with Country Flags) */}
          {settingsTab === 'lang' && (
            <div className="space-y-1.5 pt-1">
              <span className={`text-[10px] uppercase font-bold tracking-wider ${
                isDark ? 'text-[#9CA3AF]' : 'text-[#6B7280]'
              }`}>
                {t('language')}
              </span>

              <div className="space-y-1 max-h-[260px] overflow-y-auto pr-1">
                {languages.map((l) => (
                  <button
                    key={l.code}
                    onClick={() => handleLangChange(l.code)}
                    className={`w-full py-2 px-3 rounded-lg border text-left text-xs font-bold transition-all cursor-pointer flex items-center justify-between ${
                      lang === l.code
                        ? (isDark 
                            ? 'bg-[#161c28] border-[#3b82f6] text-[#FFFFFF]' 
                            : 'bg-[#EFF6FF] border-[#3b82f6] text-[#1D4ED8]')
                        : (isDark 
                            ? 'bg-[#111620] border-[#1f2634] text-[#9CA3AF] hover:text-[#FFFFFF]' 
                            : 'bg-[#F9FAFB] border-[#E5E7EB] text-[#6B7280] hover:text-[#111827]')
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <l.Flag className="w-5 h-3.5 rounded-xs" />
                      <span>{l.label}</span>
                    </div>
                    {lang === l.code && (
                      <span className="w-2 h-2 rounded-full bg-[#3b82f6]" />
                    )}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Page 3: Hakkında (About) */}
          {settingsTab === 'about' && (
            <div className="space-y-3 pt-1">
              <div className="space-y-2">
                <span className={`text-[10px] uppercase font-bold tracking-wider ${
                  isDark ? 'text-[#9CA3AF]' : 'text-[#6B7280]'
                }`}>
                  {t('contact')}
                </span>

                {/* Telegram */}
                <button
                  onClick={() => openLink('https://t.me/El_bahram')}
                  className={`w-full p-2.5 rounded-xl border flex items-center justify-between transition-all cursor-pointer group ${
                    isDark 
                      ? 'bg-[#111620] border-[#1f2634] hover:border-[#0088cc] hover:bg-[#161c28]' 
                      : 'bg-[#F9FAFB] border-[#E5E7EB] hover:border-[#0088cc] hover:bg-[#EFF6FF]'
                  }`}
                >
                  <div className="flex items-center space-x-2.5">
                    <div className="w-7 h-7 rounded-lg bg-[#0088cc]/15 text-[#0088cc] flex items-center justify-center shrink-0">
                      <IconTelegram className="w-4 h-4" />
                    </div>
                    <div className="text-left">
                      <div className="text-[10px] text-zinc-400 font-medium">Telegram</div>
                      <div className={`text-xs font-bold ${isDark ? 'text-[#FFFFFF]' : 'text-[#111827]'}`}>@El_bahram</div>
                    </div>
                  </div>
                  <span className="text-[11px] text-zinc-500 group-hover:text-[#0088cc] transition-colors font-mono">↗</span>
                </button>

                {/* YouTube */}
                <button
                  onClick={() => openLink('https://youtube.com/@orucdemiros')}
                  className={`w-full p-2.5 rounded-xl border flex items-center justify-between transition-all cursor-pointer group ${
                    isDark 
                      ? 'bg-[#111620] border-[#1f2634] hover:border-[#ff0000] hover:bg-[#161c28]' 
                      : 'bg-[#F9FAFB] border-[#E5E7EB] hover:border-[#ff0000] hover:bg-[#EFF6FF]'
                  }`}
                >
                  <div className="flex items-center space-x-2.5">
                    <div className="w-7 h-7 rounded-lg bg-[#ff0000]/15 text-[#ff0000] flex items-center justify-center shrink-0">
                      <IconYoutube className="w-4 h-4" />
                    </div>
                    <div className="text-left">
                      <div className="text-[10px] text-zinc-400 font-medium">YouTube</div>
                      <div className={`text-xs font-bold ${isDark ? 'text-[#FFFFFF]' : 'text-[#111827]'}`}>@orucdemiros</div>
                    </div>
                  </div>
                  <span className="text-[11px] text-zinc-500 group-hover:text-[#ff0000] transition-colors font-mono">↗</span>
                </button>

                {/* GitHub */}
                <button
                  onClick={() => openLink('https://github.com/Elbahram0')}
                  className={`w-full p-2.5 rounded-xl border flex items-center justify-between transition-all cursor-pointer group ${
                    isDark 
                      ? 'bg-[#111620] border-[#1f2634] hover:border-white hover:bg-[#161c28]' 
                      : 'bg-[#F9FAFB] border-[#E5E7EB] hover:border-black hover:bg-[#EFF6FF]'
                  }`}
                >
                  <div className="flex items-center space-x-2.5">
                    <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${
                      isDark ? 'bg-white/10 text-white' : 'bg-black/10 text-black'
                    }`}>
                      <IconGithub className="w-4 h-4" />
                    </div>
                    <div className="text-left">
                      <div className="text-[10px] text-zinc-400 font-medium">GitHub</div>
                      <div className={`text-xs font-bold ${isDark ? 'text-[#FFFFFF]' : 'text-[#111827]'}`}>Elbahram0</div>
                    </div>
                  </div>
                  <span className="text-[11px] text-zinc-500 group-hover:text-white transition-colors font-mono">↗</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Drawer Bottom */}
        <div />

      </div>

      {/* Backdrop overlay when settings drawer is open */}
      {showSettings && (
        <div 
          style={{ WebkitAppRegion: 'no-drag' } as React.CSSProperties}
          onClick={() => setShowSettings(false)}
          className="absolute inset-0 bg-black/60 z-40 backdrop-blur-xs transition-opacity cursor-pointer"
        />
      )}

    </div>
  );
}