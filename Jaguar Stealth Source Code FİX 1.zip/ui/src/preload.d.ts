/// <reference types="vite/client" />

declare module "*.png" {
  const value: string;
  export default value;
}

declare module "*.jpg" {
  const value: string;
  export default value;
}

declare module "*.svg" {
  const value: string;
  export default value;
}

import { JaguarAPI } from './main/preload';

declare global {
  interface Window {
    jaguar: JaguarAPI;
  }
}