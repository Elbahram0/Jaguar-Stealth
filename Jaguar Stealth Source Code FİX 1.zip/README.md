# Jaguar Stealth

Windows için yerel DPI baypas ve DNS-over-HTTPS (DoH) aracı.

Harici bir VPN veya uzak sunucuya bağlanmadan, paketleri yerel olarak (WinDivert kernel sürücüsü ile) parçalayarak DPI filtrelerini aşar.

---

## 🚀 Başlangıç ve Çalıştırma

> **Not:** WinDivert kernel paket sürücüsü gerektirdiği için uygulamanın **Yönetici Olarak (Run as Administrator)** çalıştırılması gerekir.

### Geliştirme Modu:
```powershell
# Bağımlılıkları yükleyin ve arayüzü başlatın
cd ui
npm install
npm run dev
```

### Derleme (Tek Tıkla Paketleme):
```powershell
# Proje ana dizininde:
.\build.ps1
```

---

## 🛠 Mimari

- **`core/`**: Go ile yazılmış yerel servis (`jaguar-core.exe`, WinDivert sürücüsü, TCP ClientHello SNI parçalama, DoH paralel DNS sorgulama).
- **`ui/`**: Electron + React + TailwindCSS ile geliştirilmiş sistem tepsisi (System Tray) arayüzü.

---

## 👤 İletişim

- **Telegram:** [@El_bahram](https://t.me/El_bahram)
- **YouTube:** [@orucdemiros](https://youtube.com/@orucdemiros)
- **GitHub:** [Elbahram0](https://github.com/Elbahram0)
