package main

import (
	"flag"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"
	"unsafe"

	"jaguar-core/internal/api"
	"jaguar-core/internal/dns"
	"jaguar-core/internal/engine"
)

func main() {
	port := flag.Int("port", 18231, "Port for local REST API")
	autoStart := flag.Bool("autostart", false, "Automatically start WinDivert engine on launch")
	dohProvider := flag.String("doh", "cloudflare", "DoH provider (cloudflare, google, quad9)")
	parentPid := flag.Int("parent-pid", 0, "Parent process PID to monitor")
	flag.Parse()

	log.Printf("[Jaguar Core] Initializing on 127.0.0.1:%d ...", *port)

	// Initialize Engine
	cfg := engine.DefaultConfig()
	eng := engine.NewEngine(cfg)

	// Parent process watcher: automatically terminates if parent Electron process exits or crashes
	if *parentPid > 0 {
		go func() {
			kernel32 := syscall.NewLazyDLL("kernel32.dll")
			openProcess := kernel32.NewProc("OpenProcess")
			getExitCodeProcess := kernel32.NewProc("GetExitCodeProcess")
			closeHandle := kernel32.NewProc("CloseHandle")

			for {
				time.Sleep(1500 * time.Millisecond)
				// PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
				handle, _, _ := openProcess.Call(0x1000, 0, uintptr(*parentPid))
				if handle == 0 {
					log.Printf("[Jaguar Core] Parent PID %d gone. Terminating...", *parentPid)
					_ = eng.Stop()
					os.Exit(0)
				}
				var exitCode uint32
				res, _, _ := getExitCodeProcess.Call(handle, uintptr(unsafe.Pointer(&exitCode)))
				closeHandle.Call(handle)

				if res == 0 || exitCode != 259 {
					log.Printf("[Jaguar Core] Parent PID %d exited (%d). Terminating...", *parentPid, exitCode)
					_ = eng.Stop()
					os.Exit(0)
				}
			}
		}()
	}

	// Initialize DoH Client
	dnsClient := dns.NewClient(dns.Provider(*dohProvider))

	// If autostart requested
	if *autoStart {
		log.Println("[Jaguar Core] Auto-starting WinDivert packet engine...")
		if err := eng.Start(); err != nil {
			log.Printf("[Jaguar Core] Warning: Auto-start failed: %v", err)
		}
	}

	// Initialize API Server
	apiServer := api.NewServer(eng, dnsClient)
	httpServer := &http.Server{
		Addr:         fmt.Sprintf("127.0.0.1:%d", *port),
		Handler:      apiServer.Router(),
		ReadTimeout:  10 * time.Second,
		WriteTimeout: 10 * time.Second,
	}

	// Graceful shutdown channel
	stopChan := make(chan os.Signal, 1)
	signal.Notify(stopChan, os.Interrupt, syscall.SIGTERM)

	go func() {
		log.Printf("[Jaguar Core] API server listening at http://127.0.0.1:%d", *port)
		if err := httpServer.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("[Jaguar Core] HTTP server error: %v", err)
		}
	}()

	<-stopChan
	log.Println("[Jaguar Core] Shutting down...")

	// Stop Engine
	_ = eng.Stop()

	log.Println("[Jaguar Core] Shutdown complete.")
}
