package api

import (
	"net/http"
)

func (s *Server) Router() http.Handler {
	mux := http.NewServeMux()

	mux.HandleFunc("/v1/status", s.HandleStatus)
	mux.HandleFunc("/v1/start", s.HandleStart)
	mux.HandleFunc("/v1/stop", s.HandleStop)
	mux.HandleFunc("/v1/shutdown", s.HandleShutdown)
	mux.HandleFunc("/v1/config", s.HandleConfig)
	mux.HandleFunc("/v1/dns/resolve", s.HandleResolveDNS)

	// Wrap with CORS middleware
	return corsMiddleware(mux)
}

func corsMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
		w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")

		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusOK)
			return
		}

		next.ServeHTTP(w, r)
	})
}
