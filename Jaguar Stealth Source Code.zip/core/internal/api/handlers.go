package api

import (
	"encoding/json"
	"net/http"
	"os"
	"time"

	"jaguar-core/internal/dns"
	"jaguar-core/internal/engine"
)

type Server struct {
	engine    *engine.Engine
	dnsClient *dns.Client
	startTime time.Time
}

func NewServer(eng *engine.Engine, dnsClient *dns.Client) *Server {
	return &Server{
		engine:    eng,
		dnsClient: dnsClient,
		startTime: time.Now(),
	}
}

type StatusResponse struct {
	Running     bool               `json:"running"`
	Version     string             `json:"version"`
	UptimeSec   int64              `json:"uptime_sec"`
	Stats       engine.EngineStats `json:"stats"`
	Config      engine.EngineConfig`json:"config"`
	DoHProvider string             `json:"doh_provider"`
}

func (s *Server) HandleStatus(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	stats := s.engine.GetStats()
	cfg := s.engine.GetConfig()

	resp := StatusResponse{
		Running:     s.engine.IsRunning(),
		Version:     "1.0.0",
		UptimeSec:   int64(time.Since(s.startTime).Seconds()),
		Stats:       stats,
		Config:      cfg,
		DoHProvider: string(s.dnsClient.GetProvider()),
	}

	writeJSON(w, http.StatusOK, resp)
}

func (s *Server) HandleStart(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	if err := s.engine.Start(); err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   err.Error(),
		})
		return
	}

	writeJSON(w, http.StatusOK, map[string]interface{}{
		"success": true,
		"message": "WinDivert engine started successfully",
		"running": true,
	})
}

func (s *Server) HandleStop(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	if err := s.engine.Stop(); err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   err.Error(),
		})
		return
	}

	writeJSON(w, http.StatusOK, map[string]interface{}{
		"success": true,
		"message": "WinDivert engine stopped",
		"running": false,
	})
}

func (s *Server) HandleShutdown(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	// Cleanly stop engine & unhook WinDivert kernel driver
	_ = s.engine.Stop()

	writeJSON(w, http.StatusOK, map[string]interface{}{
		"success": true,
		"message": "Shutting down jaguar-core",
	})

	// Exit process after writing response
	go func() {
		time.Sleep(100 * time.Millisecond)
		os.Exit(0)
	}()
}

type ConfigUpdateRequest struct {
	SplitPosition  *int     `json:"split_position,omitempty"`
	IncludeDomains []string `json:"include_domains,omitempty"`
	ExcludeDomains []string `json:"exclude_domains,omitempty"`
	DoHProvider    string   `json:"doh_provider,omitempty"`
}

func (s *Server) HandleConfig(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var req ConfigUpdateRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid JSON payload", http.StatusBadRequest)
		return
	}

	cfg := s.engine.GetConfig()
	if req.SplitPosition != nil {
		cfg.SplitPosition = *req.SplitPosition
	}
	if req.IncludeDomains != nil {
		cfg.IncludeDomains = req.IncludeDomains
	}
	if req.ExcludeDomains != nil {
		cfg.ExcludeDomains = req.ExcludeDomains
	}
	s.engine.SetConfig(cfg)

	if req.DoHProvider != "" {
		s.dnsClient.SetProvider(dns.Provider(req.DoHProvider))
	}

	writeJSON(w, http.StatusOK, map[string]interface{}{
		"success": true,
		"config":  s.engine.GetConfig(),
		"doh":     s.dnsClient.GetProvider(),
	})
}

func (s *Server) HandleResolveDNS(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	domain := r.URL.Query().Get("domain")
	if domain == "" {
		http.Error(w, "Query parameter 'domain' is required", http.StatusBadRequest)
		return
	}

	ips, err := s.dnsClient.Resolve(r.Context(), domain)
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   err.Error(),
		})
		return
	}

	writeJSON(w, http.StatusOK, map[string]interface{}{
		"success": true,
		"domain":  domain,
		"ips":     ips,
	})
}

func writeJSON(w http.ResponseWriter, code int, v interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}
