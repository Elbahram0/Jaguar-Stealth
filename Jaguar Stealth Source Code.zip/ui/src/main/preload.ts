const { contextBridge, ipcRenderer } = require('electron');

const api = {
  getStatus: () => ipcRenderer.invoke('api:getStatus'),
  startService: () => ipcRenderer.invoke('api:startService'),
  stopService: () => ipcRenderer.invoke('api:stopService'),
  updateConfig: (cfg: any) => ipcRenderer.invoke('api:updateConfig', cfg),
  resolveDNS: (domain: string) => ipcRenderer.invoke('api:resolveDNS', domain),
  hideWindow: () => ipcRenderer.send('window:hide'),
  quitApp: () => ipcRenderer.send('app:quit'),
  openExternal: (url: string) => ipcRenderer.send('app:openExternal', url),
  getAutoStart: () => ipcRenderer.invoke('app:getAutoStart'),
  setAutoStart: (enable: boolean) => ipcRenderer.invoke('app:setAutoStart', enable),
  getSettings: () => ipcRenderer.invoke('app:getSettings'),
  saveSettings: (settings: any) => ipcRenderer.invoke('app:saveSettings', settings),
};

contextBridge.exposeInMainWorld('jaguar', api);
export type JaguarAPI = typeof api;